import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"
import { ChevronRight, Calendar, User, Tag } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"

export async function generateStaticParams() {
  return [
    { slug: "best-photo-editing-apps-2025" },
    { slug: "increase-instagram-followers-2025" },
    { slug: "professional-video-content-guide" },
  ]
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const { slug } = params

  const blogPosts: Record<string, { title: string; description: string }> = {
    "best-photo-editing-apps-2025": {
      title: "أفضل 10 تطبيقات لتحرير الصور في 2025",
      description:
        "استعراض لأفضل تطبيقات تحرير الصور المتاحة حالياً مع شرح مميزات كل منها وكيفية استخدامها للحصول على أفضل النتائج.",
    },
    "increase-instagram-followers-2025": {
      title: "كيفية زيادة متابعينك على انستقرام في 2025",
      description:
        "نصائح وإستراتيجيات فعالة لزيادة عدد متابعيك على انستقرام وتحسين التفاعل مع منشوراتك بطرق شرعية وفعالة.",
    },
    "professional-video-content-guide": {
      title: "دليل شامل لإنشاء محتوى فيديو احترافي",
      description:
        "خطوات تفصيلية لإنشاء محتوى فيديو احترافي باستخدام أدوات بسيطة، من مرحلة التخطيط وحتى النشر والترويج.",
    },
  }

  const post = blogPosts[slug] || {
    title: "مقال",
    description: "مقال في مدونة Pasha_jord",
  }

  return {
    title: `${post.title} | Pasha_jord`,
    description: post.description,
  }
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const { slug } = params

  const blogPosts: Record<
    string,
    {
      title: string
      category: string
      date: string
      author: string
      content: string
      image: string
    }
  > = {
    "best-photo-editing-apps-2025": {
      title: "أفضل 10 تطبيقات لتحرير الصور في 2025",
      category: "تطبيقات",
      date: "5 مايو 2025",
      author: "Pasha_jord",
      image: "/images/blog/app-collection.png",
      content: `
      <p>تعد تطبيقات تحرير الصور من أكثر التطبيقات استخداماً على الهواتف الذكية، حيث يسعى الكثيرون لتحسين صورهم ومشاركتها على وسائل التواصل الاجتماعي. في هذا المقال، سنستعرض أفضل 10 تطبيقات لتحرير الصور في عام 2025، مع شرح مميزات كل منها وكيفية استخدامها للحصول على أفضل النتائج.</p>

      <div class="my-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <img src="/images/blog/app-collection.png" alt="تطبيق Pixverse" class="rounded-lg w-full" />
        <img src="/images/blog/social-media-3d.png" alt="تطبيق Adobe Lightroom" class="rounded-lg w-full" />
      </div>

      <h2>1. Pixverse</h2>
      <p>يعد تطبيق Pixverse من أفضل تطبيقات تحرير الصور المتاحة حالياً، حيث يوفر مجموعة واسعة من الأدوات والفلاتر لتحسين صورك. يتميز التطبيق بواجهة سهلة الاستخدام وأدوات احترافية تناسب المبتدئين والمحترفين على حد سواء.</p>
      <p>أهم مميزات التطبيق:</p>
      <ul>
        <li>مجموعة متنوعة من الفلاتر والتأثيرات</li>
        <li>أدوات متقدمة لتعديل الألوان والإضاءة</li>
        <li>إمكانية إضافة نصوص وملصقات للصور</li>
        <li>قوالب جاهزة للاستخدام في السوشيال ميديا</li>
        <li>واجهة سهلة الاستخدام ومناسبة للمبتدئين والمحترفين</li>
      </ul>

      <div class="my-6">
        <img src="/images/blog/app-collection.png" alt="واجهة تطبيق Snapseed" class="rounded-lg w-full" />
      </div>

      <h2>2. Adobe Lightroom</h2>
      <p>يعتبر Adobe Lightroom من أشهر تطبيقات تحرير الصور الاحترافية، حيث يوفر أدوات متقدمة لتعديل الصور وضبط الألوان والإضاءة. يتميز التطبيق بدعمه لصيغ RAW وإمكانية حفظ الإعدادات المخصصة واستخدامها لاحقاً.</p>
      <p>أهم مميزات التطبيق:</p>
      <ul>
        <li>أدوات متقدمة لضبط الألوان والإضاءة</li>
        <li>دعم لصيغ RAW</li>
        <li>إمكانية حفظ الإعدادات المخصصة</li>
        <li>مزامنة الصور عبر الأجهزة المختلفة</li>
        <li>أدوات احترافية للتحكم في تفاصيل الصورة</li>
      </ul>

      <h2>3. Snapseed</h2>
      <p>تطبيق Snapseed من Google هو أحد أفضل تطبيقات تحرير الصور المجانية، حيث يوفر مجموعة كبيرة من الأدوات الاحترافية بواجهة بسيطة وسهلة الاستخدام. يتميز التطبيق بأدواته الدقيقة للتحكم في تفاصيل الصورة.</p>
      <p>أهم مميزات التطبيق:</p>
      <ul>
        <li>29 أداة وفلتر لتحرير الصور</li>
        <li>أدوات متقدمة مثل Selective و Healing</li>
        <li>إمكانية تعديل منحنيات الألوان</li>
        <li>حفظ الإعدادات واستخدامها على صور أخرى</li>
        <li>دعم لصيغ RAW</li>
      </ul>

      <div class="my-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <img src="/images/blog/social-media-apps.png" alt="تطبيق VSCO" class="rounded-lg w-full" />
        <img src="/images/blog/app-collection.png" alt="تطبيق Canva" class="rounded-lg w-full" />
      </div>

      <h2>4. VSCO</h2>
      <p>يعد VSCO من التطبيقات المفضلة لدى المصورين ومحبي التصوير، حيث يوفر مجموعة مميزة من الفلاتر ذات الطابع السينمائي. يتميز التطبيق بواجهته البسيطة والأنيقة وجودة فلاتره العالية.</p>
      <p>أهم مميزات التطبيق:</p>
      <ul>
        <li>فلاتر ذات طابع سينمائي</li>
        <li>أدوات أساسية لتعديل الصور</li>
        <li>مجتمع للمصورين لمشاركة الصور والإلهام</li>
        <li>إمكانية شراء مجموعات فلاتر إضافية</li>
        <li>واجهة بسيطة وأنيقة</li>
      </ul>

      <h2>5. Canva</h2>
      <p>يعتبر Canva من أفضل التطبيقات لإنشاء تصاميم احترافية للسوشيال ميديا، حيث يوفر قوالب جاهزة ومجموعة كبيرة من العناصر والخطوط. يمكن استخدامه لتحرير الصور وإضافة نصوص وعناصر مختلفة.</p>
      <p>أهم مميزات التطبيق:</p>
      <ul>
        <li>قوالب جاهزة لمختلف منصات التواصل الاجتماعي</li>
        <li>مجموعة كبيرة من العناصر والخطوط</li>
        <li>أدوات أساسية لتحرير الصور</li>
        <li>إمكانية التعاون مع فريق العمل</li>
        <li>حفظ التصاميم بصيغ مختلفة</li>
      </ul>

      <h2>الخلاصة</h2>
      <p>تتنوع تطبيقات تحرير الصور لتناسب مختلف الاحتياجات والمستويات، من المبتدئين وحتى المحترفين. يمكنك اختيار التطبيق المناسب لك بناءً على احتياجاتك وخبرتك في مجال تحرير الصور. نوصي بتجربة Pixverse للحصول على نتائج احترافية بواجهة سهلة الاستخدام.</p>
    `,
    },
    "increase-instagram-followers-2025": {
      title: "كيفية زيادة متابعينك على انستقرام في 2025",
      category: "السوشيال ميديا",
      date: "2 مايو 2025",
      author: "Pasha_jord",
      image: "/images/blog/social-media-apps.png",
      content: `
      <p>يعد انستقرام من أكثر منصات التواصل الاجتماعي شعبية في العالم، حيث يستخدمه المليارات من الأشخاص يومياً. في هذا المقال، سنستعرض أفضل الاستراتيجيات لزيادة عدد متابعيك على انستقرام في عام 2025، مع مراعاة أحدث تحديثات الخوارزمية.</p>

      <div class="my-6">
        <img src="/images/blog/social-media-apps.png" alt="تحسين ملف انستقرام الشخصي" class="rounded-lg w-full" />
      </div>

      <h2>1. تحسين ملفك الشخصي</h2>
      <p>يعد ملفك الشخصي هو واجهتك الأولى للزوار، لذا يجب الاهتمام بتحسينه وجعله جذاباً ومميزاً:</p>
      <ul>
        <li>استخدم صورة شخصية واضحة وجذابة</li>
        <li>اكتب وصفاً مختصراً ومميزاً يعبر عن هويتك أو نشاطك</li>
        <li>أضف رابطاً لموقعك الإلكتروني أو قناتك على يوتيوب</li>
        <li>استخدم الكلمات المفتاحية المناسبة في وصفك</li>
        <li>حافظ على اتساق هوية حسابك البصرية</li>
      </ul>

      <div class="my-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <img src="/images/blog/social-media-3d.png" alt="محتوى عالي الجودة" class="rounded-lg w-full" />
        <img src="/images/blog/social-media-apps.png" alt="هاشتاغات انستقرام" class="rounded-lg w-full" />
      </div>

      <h2>2. نشر محتوى عالي الجودة وبانتظام</h2>
      <p>يعد المحتوى هو العامل الأساسي لجذب المتابعين والحفاظ عليهم. احرص على نشر محتوى عالي الجودة وبانتظام:</p>
      <ul>
        <li>استخدم صوراً وفيديوهات عالية الجودة</li>
        <li>حافظ على جدول نشر منتظم</li>
        <li>تنويع المحتوى بين الصور والفيديوهات والقصص والريلز</li>
        <li>استخدم تطبيقات تحرير الصور مثل Pixverse لتحسين جودة صورك</li>
        <li>اهتم بكتابة تعليقات جذابة ومفيدة لمنشوراتك</li>
      </ul>

      <h2>3. استخدام الهاشتاغات بذكاء</h2>
      <p>تلعب الهاشتاغات دوراً مهماً في زيادة وصول منشوراتك لجمهور أوسع. استخدم الهاشتاغات بذكاء:</p>
      <ul>
        <li>استخدم مزيجاً من الهاشتاغات الشائعة والمتخصصة</li>
        <li>لا تستخدم أكثر من 10-15 هاشتاغ في المنشور الواحد</li>
        <li>ابحث عن الهاشتاغات المناسبة لمجالك</li>
        <li>أنشئ هاشتاغ خاص بك واستخدمه باستمرار</li>
        <li>تجنب استخدام الهاشتاغات المحظورة</li>
      </ul>

      <div class="my-6">
        <img src="/images/blog/social-media-3d.png" alt="التفاعل مع الجمهور على انستقرام" class="rounded-lg w-full" />
      </div>

      <h2>4. التفاعل مع الجمهور</h2>
      <p>يعد التفاعل مع الجمهور من أهم العوامل لبناء مجتمع نشط حول حسابك:</p>
      <ul>
        <li>الرد على التعليقات والرسائل</li>
        <li>التفاعل مع منشورات متابعيك</li>
        <li>استخدام استطلاعات الرأي والأسئلة في القصص</li>
        <li>إشراك الجمهور في محتواك من خلال طرح الأسئلة</li>
        <li>تنظيم مسابقات وهدايا للمتابعين</li>
      </ul>

      <div class="my-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <img src="/images/blog/social-media-apps.png" alt="ريلز انستقرام" class="rounded-lg w-full" />
        <img src="/images/blog/social-media-3d.png" alt="تحليلات انستقرام" class="rounded-lg w-full" />
      </div>

      <h2>5. الاستفادة من ميزة الريلز</h2>
      <p>أصبحت ميزة الريلز من أهم ميزات انستقرام لزيادة الوصول والانتشار:</p>
      <ul>
        <li>إنشاء ريلز قصيرة وجذابة</li>
        <li>استخدام الموسيقى والمؤثرات الشائعة</li>
        <li>المشاركة في التحديات الشائعة</li>
        <li>نشر ريلز بانتظام</li>
        <li>استخدام تطبيق CapCut لتحرير الريلز بشكل احترافي</li>
      </ul>

      <h2>الخلاصة</h2>
      <p>زيادة عدد المتابعين على انستقرام تتطلب استراتيجية متكاملة تشمل تحسين ملفك الشخصي، ونشر محتوى عالي الجودة، واستخدام الهاشتاغات بذكاء، والتفاعل مع الجمهور، والاستفادة من ميزة الريلز. تطبيق هذه الاستراتيجيات بانتظام سيساعدك على زيادة عدد متابعيك وتحسين تفاعلهم مع محتواك.</p>
    `,
    },
    "professional-video-content-guide": {
      title: "دليل شامل لإنشاء محتوى فيديو احترافي",
      category: "إنشاء المحتوى",
      date: "28 أبريل 2025",
      author: "Pasha_jord",
      image: "/images/blog/web-design-purple.png",
      content: `
      <p>أصبح محتوى الفيديو من أكثر أنواع المحتوى شعبية وتأثيراً على منصات التواصل الاجتماعي. في هذا الدليل الشامل، سنتعرف على خطوات إنشاء محتوى فيديو احترافي باستخدام أدوات بسيطة، من مرحلة التخطيط وحتى النشر والترويج.</p>

      <div class="my-6">
        <img src="/images/blog/web-design-purple.png" alt="تخطيط الفيديو" class="rounded-lg w-full" />
      </div>

      <h2>1. التخطيط والإعداد</h2>
      <p>تعد مرحلة التخطيط من أهم مراحل إنشاء محتوى فيديو ناجح:</p>
      <ul>
        <li>تحديد الهدف من الفيديو والجمهور المستهدف</li>
        <li>كتابة سيناريو أو مخطط للفيديو</li>
        <li>تحديد أسلوب العرض والتصوير</li>
        <li>تجهيز المعدات اللازمة (كاميرا، ميكروفون، إضاءة)</li>
        <li>اختيار موقع التصوير المناسب</li>
      </ul>

      <div class="my-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <img src="/images/blog/web-design-interactive.png" alt="تصوير الفيديو" class="rounded-lg w-full" />
        <img src="/images/blog/web-development.png" alt="تحرير الفيديو" class="rounded-lg w-full" />
      </div>

      <h2>2. التصوير</h2>
      <p>خلال مرحلة التصوير، احرص على اتباع هذه النصائح للحصول على لقطات احترافية:</p>
      <ul>
        <li>استخدم حامل ثلاثي للكاميرا لتجنب اهتزاز الصورة</li>
        <li>اهتم بالإضاءة الجيدة (يفضل الإضاءة الطبيعية أو استخدام إضاءة احترافية)</li>
        <li>استخدم ميكروفون خارجي للحصول على صوت واضح</li>
        <li>صور لقطات إضافية يمكن استخدامها في المونتاج</li>
        <li>تأكد من وضوح الصورة والتركيز على العناصر المهمة</li>
      </ul>

      <h2>3. المونتاج والتحرير</h2>
      <p>يعد المونتاج من أهم مراحل إنشاء محتوى فيديو احترافي. استخدم تطبيق CapCut للحصول على نتائج احترافية:</p>
      <ul>
        <li>اختيار أفضل اللقطات وترتيبها بشكل منطقي</li>
        <li>إضافة مقدمة وخاتمة جذابة</li>
        <li>إضافة موسيقى مناسبة للفيديو</li>
        <li>إضافة نصوص وعناوين توضيحية</li>
        <li>ضبط الألوان والإضاءة لتحسين جودة الفيديو</li>
        <li>إضافة مؤثرات انتقالية بين المشاهد</li>
      </ul>

      <div class="my-6">
        <img src="/images/blog/web-design-interactive.png" alt="نشر الفيديو" class="rounded-lg w-full" />
      </div>

      <h2>4. التصدير والنشر</h2>
      <p>بعد الانتهاء من تحرير الفيديو، حان وقت تصديره ونشره:</p>
      <ul>
        <li>اختيار دقة مناسبة للفيديو (يفضل 1080p أو أعلى)</li>
        <li>اختيار صيغة مناسبة للمنصة التي ستنشر عليها</li>
        <li>إضافة عنوان جذاب ووصف مفصل للفيديو</li>
        <li>إضافة الهاشتاغات المناسبة</li>
        <li>اختيار صورة مصغرة جذابة للفيديو</li>
        <li>نشر الفيديو في الوقت المناسب للجمهور المستهدف</li>
      </ul>

      <h2>5. الترويج والتفاعل</h2>
      <p>لا يكفي نشر الفيديو فقط، بل يجب الترويج له والتفاعل مع المشاهدين:</p>
      <ul>
        <li>مشاركة الفيديو على مختلف منصات التواصل الاجتماعي</li>
        <li>الرد على تعليقات المشاهدين</li>
        <li>تحليل أداء الفيديو وتحسين المحتوى المستقبلي بناءً على النتائج</li>
        <li>التعاون مع صناع محتوى آخرين لزيادة الانتشار</li>
        <li>استخدام الإعلانات المدفوعة للوصول لجمهور أوسع</li>
      </ul>

      <div class="my-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <img src="/images/blog/web-development.png" alt="تحليلات الفيديو" class="rounded-lg w-full" />
        <img src="/images/blog/web-design-interactive.png" alt="ترويج الفيديو" class="rounded-lg w-full" />
      </div>

      <h2>الخلاصة</h2>
      <p>إنشاء محتوى فيديو احترافي يتطلب التخطيط الجيد والاهتمام بالتفاصيل في كل مرحلة من مراحل الإنتاج. باستخدام الأدوات المناسبة مثل CapCut والاهتمام بجودة التصوير والمونتاج، يمكنك إنشاء محتوى فيديو مميز يجذب المشاهدين ويحقق أهدافك. تذكر أن التحسين المستمر والتعلم من التجارب السابقة هو مفتاح النجاح في إنشاء محتوى فيديو احترافي.</p>
    `,
    },
  }

  const post = blogPosts[slug] || {
    title: "مقال غير موجود",
    category: "عام",
    date: "1 يناير 2025",
    author: "Pasha_jord",
    image: "/images/blog/web-development.png",
    content: "<p>المقال غير موجود أو تم حذفه.</p>",
  }

  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="flex flex-wrap gap-2 items-center text-sm text-muted-foreground mb-4">
                <Link href="/blog" className="hover:text-primary">
                  المدونة
                </Link>
                <ChevronRight className="h-4 w-4" />
                <span>{post.category}</span>
                <ChevronRight className="h-4 w-4" />
                <span className="truncate max-w-[200px]">{post.title}</span>
              </div>
              <h1 className="text-4xl font-bold mb-6">{post.title}</h1>
              <div className="flex flex-wrap gap-4 items-center text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Tag className="h-4 w-4" />
                  <span>{post.category}</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
              <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
            </div>

            <article className="prose prose-lg dark:prose-invert max-w-none">
              <div dangerouslySetInnerHTML={{ __html: post.content }} />
            </article>

            <div className="mt-12 pt-8 border-t">
              <h3 className="text-2xl font-bold mb-6">مقالات ذات صلة</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {Object.entries(blogPosts)
                  .filter(([key]) => key !== slug)
                  .slice(0, 3)
                  .map(([key, relatedPost]) => (
                    <Link key={key} href={`/blog/${key}`} className="block">
                      <div className="bg-card rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                        <div className="relative h-40">
                          <Image
                            src={relatedPost.image || "/placeholder.svg"}
                            alt={relatedPost.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="p-4">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-xs font-medium text-primary">{relatedPost.category}</span>
                            <span className="text-xs text-muted-foreground">{relatedPost.date}</span>
                          </div>
                          <h4 className="font-bold line-clamp-2 mb-2">{relatedPost.title}</h4>
                          <Button variant="ghost" size="sm" className="mt-2">
                            قراءة المقال
                            <ChevronRight className="mr-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </div>

        <AdBanner />
      </main>

      <Footer />
    </div>
  )
}
