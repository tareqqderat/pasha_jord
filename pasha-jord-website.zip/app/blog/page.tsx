import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, ChevronRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"

export const metadata = {
  title: "المدونة | Pasha_jord",
  description: "مقالات ونصائح حول التطبيقات والمواقع وإنشاء المحتوى",
}

export default function BlogPage() {
  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl font-bold">المدونة</h1>
              <p className="text-xl text-muted-foreground">مقالات ونصائح حول التطبيقات والمواقع وإنشاء المحتوى</p>
              <div className="relative max-w-md mx-auto mt-8">
                <Search className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input type="search" placeholder="ابحث في المدونة..." className="pr-10 py-6" />
              </div>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Categories */}
        <section className="container mx-auto px-4 py-8">
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="all" className="text-lg py-3">
                الكل
              </TabsTrigger>
              <TabsTrigger value="apps" className="text-lg py-3">
                تطبيقات
              </TabsTrigger>
              <TabsTrigger value="social" className="text-lg py-3">
                السوشيال ميديا
              </TabsTrigger>
              <TabsTrigger value="content" className="text-lg py-3">
                إنشاء المحتوى
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <BlogCard
                  title="أفضل 10 تطبيقات لتحرير الصور في 2025"
                  category="تطبيقات"
                  date="5 مايو 2025"
                  excerpt="استعراض لأفضل تطبيقات تحرير الصور المتاحة حالياً مع شرح مميزات كل منها وكيفية استخدامها للحصول على أفضل النتائج."
                  slug="best-photo-editing-apps-2025"
                />
                <BlogCard
                  title="كيفية زيادة متابعينك على انستقرام في 2025"
                  category="السوشيال ميديا"
                  date="2 مايو 2025"
                  excerpt="نصائح وإستراتيجيات فعالة لزيادة عدد متابعيك على انستقرام وتحسين التفاعل مع منشوراتك بطرق شرعية وفعالة."
                  slug="increase-instagram-followers-2025"
                />
                <BlogCard
                  title="دليل شامل لإنشاء محتوى فيديو احترافي"
                  category="إنشاء المحتوى"
                  date="28 أبريل 2025"
                  excerpt="خطوات تفصيلية لإنشاء محتوى فيديو احترافي باستخدام أدوات بسيطة، من مرحلة التخطيط وحتى النشر والترويج."
                  slug="professional-video-content-guide"
                />
                <BlogCard
                  title="مقارنة بين أفضل تطبيقات تحرير الفيديو للهواتف"
                  category="تطبيقات"
                  date="25 أبريل 2025"
                  excerpt="مقارنة شاملة بين أشهر تطبيقات تحرير الفيديو للهواتف الذكية، مع توضيح نقاط القوة والضعف لكل تطبيق."
                  slug="best-video-editing-apps-comparison"
                />
                <BlogCard
                  title="كيفية استخدام تيك توك لتنمية عملك التجاري"
                  category="السوشيال ميديا"
                  date="20 أبريل 2025"
                  excerpt="دليل عملي لاستخدام منصة تيك توك في التسويق وزيادة المبيعات وبناء علامة تجارية قوية على المنصة."
                  slug="tiktok-for-business-growth"
                />
                <BlogCard
                  title="أساسيات التصوير الاحترافي باستخدام الهاتف"
                  category="إنشاء المحتوى"
                  date="15 أبريل 2025"
                  excerpt="نصائح وتقنيات لالتقاط صور احترافية باستخدام هاتفك الذكي، مع شرح لأساسيات الإضاءة والتكوين والزوايا."
                  slug="professional-smartphone-photography"
                />
                <BlogCard
                  title="أفضل تطبيقات إدارة المهام والإنتاجية"
                  category="تطبيقات"
                  date="10 أبريل 2025"
                  excerpt="استعراض لأفضل تطبيقات إدارة المهام وزيادة الإنتاجية، مع نصائح لاختيار التطبيق المناسب لاحتياجاتك."
                  slug="best-productivity-apps"
                />
                <BlogCard
                  title="استراتيجيات فعالة للتسويق عبر يوتيوب"
                  category="السوشيال ميديا"
                  date="5 أبريل 2025"
                  excerpt="دليل شامل للتسويق عبر يوتيوب، يتضمن نصائح لإنشاء محتوى جذاب وزيادة المشاهدات والاشتراكات."
                  slug="youtube-marketing-strategies"
                />
                <BlogCard
                  title="كيفية إنشاء محتوى مميز للسوشيال ميديا"
                  category="إنشاء المحتوى"
                  date="1 أبريل 2025"
                  excerpt="نصائح وأفكار لإنشاء محتوى مميز وجذاب لمختلف منصات التواصل الاجتماعي، مع أمثلة عملية ناجحة."
                  slug="creating-engaging-social-media-content"
                />
              </div>
            </TabsContent>

            <TabsContent value="apps" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <BlogCard
                  title="أفضل 10 تطبيقات لتحرير الصور في 2025"
                  category="تطبيقات"
                  date="5 مايو 2025"
                  excerpt="استعراض لأفضل تطبيقات تحرير الصور المتاحة حالياً مع شرح مميزات كل منها وكيفية استخدامها للحصول على أفضل النتائج."
                  slug="best-photo-editing-apps-2025"
                />
                <BlogCard
                  title="مقارنة بين أفضل تطبيقات تحرير الفيديو للهواتف"
                  category="تطبيقات"
                  date="25 أبريل 2025"
                  excerpt="مقارنة شاملة بين أشهر تطبيقات تحرير الفيديو للهواتف الذكية، مع توضيح نقاط القوة والضعف لكل تطبيق."
                  slug="best-video-editing-apps-comparison"
                />
                <BlogCard
                  title="أفضل تطبيقات إدارة المهام والإنتاجية"
                  category="تطبيقات"
                  date="10 أبريل 2025"
                  excerpt="استعراض لأفضل تطبيقات إدارة المهام وزيادة الإنتاجية، مع نصائح لاختيار التطبيق المناسب لاحتياجاتك."
                  slug="best-productivity-apps"
                />
              </div>
            </TabsContent>

            <TabsContent value="social" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <BlogCard
                  title="كيفية زيادة متابعينك على انستقرام في 2025"
                  category="السوشيال ميديا"
                  date="2 مايو 2025"
                  excerpt="نصائح وإستراتيجيات فعالة لزيادة عدد متابعيك على انستقرام وتحسين التفاعل مع منشوراتك بطرق شرعية وفعالة."
                  slug="increase-instagram-followers-2025"
                />
                <BlogCard
                  title="كيفية استخدام تيك توك لتنمية عملك التجاري"
                  category="السوشيال ميديا"
                  date="20 أبريل 2025"
                  excerpt="دليل عملي لاستخدام منصة تيك توك في التسويق وزيادة المبيعات وبناء علامة تجارية قوية على المنصة."
                  slug="tiktok-for-business-growth"
                />
                <BlogCard
                  title="استراتيجيات فعالة للتسويق عبر يوتيوب"
                  category="السوشيال ميديا"
                  date="5 أبريل 2025"
                  excerpt="دليل شامل للتسويق عبر يوتيوب، يتضمن نصائح لإنشاء محتوى جذاب وزيادة المشاهدات والاشتراكات."
                  slug="youtube-marketing-strategies"
                />
              </div>
            </TabsContent>

            <TabsContent value="content" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <BlogCard
                  title="دليل شامل لإنشاء محتوى فيديو احترافي"
                  category="إنشاء المحتوى"
                  date="28 أبريل 2025"
                  excerpt="خطوات تفصيلية لإنشاء محتوى فيديو احترافي باستخدام أدوات بسيطة، من مرحلة التخطيط وحتى النشر والترويج."
                  slug="professional-video-content-guide"
                />
                <BlogCard
                  title="أساسيات التصوير الاحترافي باستخدام الهاتف"
                  category="إنشاء المحتوى"
                  date="15 أبريل 2025"
                  excerpt="نصائح وتقنيات لالتقاط صور احترافية باستخدام هاتفك الذكي، مع شرح لأساسيات الإضاءة والتكوين والزوايا."
                  slug="professional-smartphone-photography"
                />
                <BlogCard
                  title="كيفية إنشاء محتوى مميز للسوشيال ميديا"
                  category="إنشاء المحتوى"
                  date="1 أبريل 2025"
                  excerpt="نصائح وأفكار لإنشاء محتوى مميز وجذاب لمختلف منصات التواصل الاجتماعي، مع أمثلة عملية ناجحة."
                  slug="creating-engaging-social-media-content"
                />
              </div>
            </TabsContent>
          </Tabs>
        </section>

        <AdBanner />

        {/* Featured Posts */}
        <section className="container mx-auto px-4 py-12">
          <h2 className="text-3xl font-bold mb-8">مقالات مميزة</h2>

          <div className="grid grid-cols-1 gap-8">
            <div className="bg-card rounded-lg overflow-hidden shadow-sm">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="relative h-64 md:h-auto">
                  <Image
                    src="/images/blog/app-collection.png"
                    alt="أفضل 10 تطبيقات لتحرير الصور في 2025"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-primary">تطبيقات</span>
                      <span className="text-xs text-muted-foreground">5 مايو 2025</span>
                    </div>
                    <h3 className="text-2xl font-bold mb-4">أفضل 10 تطبيقات لتحرير الصور في 2025</h3>
                    <p className="text-muted-foreground">
                      استعراض لأفضل تطبيقات تحرير الصور المتاحة حالياً مع شرح مميزات كل منها وكيفية استخدامها للحصول على
                      أفضل النتائج. سنتناول في هذا المقال تطبيقات متنوعة تناسب مختلف المستويات من المبتدئين وحتى
                      المحترفين.
                    </p>
                  </div>
                  <Link href="/blog/best-photo-editing-apps-2025">
                    <Button className="mt-4">
                      قراءة المقال
                      <ChevronRight className="mr-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg overflow-hidden shadow-sm">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="relative h-64 md:h-auto">
                  <Image
                    src="/images/blog/social-media-apps.png"
                    alt="كيفية زيادة متابعينك على انستقرام في 2025"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-primary">السوشيال ميديا</span>
                      <span className="text-xs text-muted-foreground">2 مايو 2025</span>
                    </div>
                    <h3 className="text-2xl font-bold mb-4">كيفية زيادة متابعينك على انستقرام في 2025</h3>
                    <p className="text-muted-foreground">
                      نصائح وإستراتيجيات فعالة لزيادة عدد متابعيك على انستقرام وتحسين التفاعل مع منشوراتك بطرق شرعية
                      وفعالة. سنتعرف على أحدث خوارزميات انستقرام وكيفية الاستفادة منها لتحقيق أقصى انتشار لمحتواك.
                    </p>
                  </div>
                  <Link href="/blog/increase-instagram-followers-2025">
                    <Button className="mt-4">
                      قراءة المقال
                      <ChevronRight className="mr-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        <AdBanner />
      </main>

      <Footer />
    </div>
  )
}

function BlogCard({
  title,
  category,
  date,
  excerpt,
  slug,
}: {
  title: string
  category: string
  date: string
  excerpt: string
  slug: string
}) {
  // تحديد الصورة بناءً على الفئة
  let imageSrc = `/images/blog/default-${category.replace(/\s+/g, "-").toLowerCase()}.jpg`

  if (category === "تطبيقات") {
    imageSrc = "/images/blog/app-collection.png"
  } else if (category === "السوشيال ميديا") {
    imageSrc = "/images/blog/social-media-apps.png"
  } else if (category === "إنشاء المحتوى") {
    imageSrc = "/images/blog/web-design-purple.png"
  }

  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 bg-muted">
        <Image src={imageSrc || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <CardHeader>
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-primary">{category}</span>
          <span className="text-xs text-muted-foreground">{date}</span>
        </div>
        <CardTitle className="line-clamp-2">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3">{excerpt}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/blog/${slug}`} className="w-full">
          <Button variant="ghost" className="w-full">
            قراءة المزيد
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
