import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ChevronRight, TrendingUp } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"
import Link from "next/link"
import Image from "next/image"
import { CountdownButton } from "@/components/countdown-button"

// بيانات المواقع
const websitesData = [
  {
    id: "1",
    title: "Pixverse",
    description:
      "موقع مميز لتحرير الصور وإضافة تأثيرات احترافية. يوفر أدوات متقدمة لتعديل الصور بشكل احترافي وإنشاء تصاميم مميزة.",
    category: "تحرير الصور",
    trending: true,
    language: "الإنجليزية",
    websiteLink: "https://pixverse.ai/",
    icon: "/images/apps/pixverse.png",
    screenshots: ["/images/blog/apps-collection.jpg", "/images/blog/apps-collection.jpg"],
    features: [
      "تحرير الصور مباشرة عبر المتصفح دون الحاجة لتثبيت برامج",
      "مجموعة متنوعة من الفلاتر والتأثيرات الاحترافية",
      "أدوات متقدمة لتعديل الألوان والإضاءة والتباين",
      "إمكانية إضافة نصوص وملصقات للصور",
      "حفظ وتصدير الصور بصيغ مختلفة وبجودة عالية",
    ],
    usage: [
      "قم بزيارة موقع Pixverse",
      "ارفع الصورة التي ترغب بتعديلها",
      "استخدم الأدوات المتاحة لتحرير الصورة",
      "قم بحفظ الصورة بعد الانتهاء من التعديل",
    ],
    article: `
      <h2>موقع Pixverse: منصة متكاملة لتحرير الصور عبر الإنترنت</h2>
      
      <p>في عصر المحتوى البصري، أصبح تحرير الصور جزءًا أساسيًا من عملية إنشاء المحتوى للمنصات الرقمية المختلفة. يأتي موقع Pixverse كحل متكامل لتحرير الصور عبر الإنترنت، يجمع بين الأدوات الاحترافية وسهولة الاستخدام.</p>
      
      <p>يتميز موقع Pixverse بواجهة سهلة الاستخدام ومجموعة واسعة من الأدوات التي تلبي احتياجات المستخدمين من مختلف المستويات، من المبتدئين وحتى المحترفين. دعونا نستكشف ما يجعل هذا الموقع خيارًا مثاليًا لتحرير صورك.</p>
      
      <h3>مميزات موقع Pixverse</h3>
      
      <p><strong>1. تحرير الصور عبر المتصفح:</strong> يتيح لك Pixverse تحرير صورك مباشرة عبر المتصفح دون الحاجة لتحميل أو تثبيت أي برامج. هذا يوفر المرونة للعمل على صورك من أي جهاز متصل بالإنترنت.</p>
      
      <p><strong>2. أدوات تحرير متقدمة:</strong> يوفر الموقع مجموعة شاملة من أدوات التحرير، بما في ذلك:</p>
      <ul>
        <li>ضبط الإضاءة والتباين والتشبع</li>
        <li>تعديل الألوان وتوازن اللون الأبيض</li>
        <li>قص وتدوير وتغيير حجم الصور</li>
        <li>إزالة الخلفية تلقائيًا</li>
        <li>تصحيح العيوب وتحسين الصور الشخصية</li>
      </ul>
      
      <p><strong>3. فلاتر وتأثيرات احترافية:</strong> يحتوي Pixverse على مجموعة متنوعة من الفلاتر والتأثيرات التي يمكن تطبيقها بنقرة واحدة لتغيير مظهر صورك بالكامل.</p>
      
      <p><strong>4. إضافة نصوص وعناصر:</strong> يمكنك إضافة نصوص بخطوط متنوعة، بالإضافة إلى ملصقات ورسومات وأشكال لإثراء صورك.</p>
      
      <p><strong>5. قوالب جاهزة:</strong> يوفر الموقع قوالب جاهزة للاستخدام في مختلف المنصات الاجتماعية، مما يسهل إنشاء تصاميم احترافية بسرعة.</p>
      
      <p><strong>6. تصدير بجودة عالية:</strong> يمكنك تصدير صورك بصيغ مختلفة وبجودة عالية مناسبة للاستخدام الاحترافي.</p>
      
      <h3>كيفية استخدام موقع Pixverse</h3>
      
      <p>استخدام موقع Pixverse سهل وبسيط، حتى للمبتدئين:</p>
      
      <ol>
        <li><strong>الوصول إلى الموقع:</strong> قم بزيارة موقع Pixverse عبر متصفحك المفضل.</li>
        <li><strong>رفع الصورة:</strong> انقر على زر "رفع صورة" واختر الصورة التي ترغب في تحريرها من جهازك.</li>
        <li><strong>تحرير الصورة:</strong> استخدم الأدوات المتاحة في الشريط الجانبي لتعديل صورتك حسب رغبتك.</li>
        <li><strong>تطبيق الفلاتر والتأثيرات:</strong> اختر من مجموعة الفلاتر والتأثيرات المتاحة لإضافة لمسة مميزة لصورتك.</li>
        <li><strong>إضافة عناصر:</strong> أضف نصوصًا أو ملصقات أو أشكالًا حسب الحاجة.</li>
        <li><strong>حفظ وتصدير:</strong> بعد الانتهاء من التحرير، انقر على زر "تصدير" واختر صيغة الملف وجودة الصورة المطلوبة.</li>
      </ol>
      
      <h3>الخلاصة</h3>
      
      <p>موقع Pixverse هو منصة متكاملة لتحرير الصور عبر الإنترنت، تجمع بين الأدوات الاحترافية وسهولة الاستخدام. سواء كنت مبتدئًا أو محترفًا، يوفر لك الموقع كل ما تحتاجه لتحويل صورك العادية إلى أعمال فنية مذهلة.</p>
      
      <p>مع واجهة سهلة الاستخدام ومجموعة واسعة من الأدوات والفلاتر والقوالب، يمكنك إطلاق العنان لإبداعك وإنشاء صور تلفت الأنظار لمختلف الأغراض والمنصات.</p>
    `,
  },
  {
    id: "2",
    title: "إنشاء محادثة وهمية",
    description:
      "موقع يتيح لك إنشاء محادثات وهمية بين شخصيات مختلفة. مفيد لإنشاء محتوى ترفيهي أو تعليمي وإنشاء سيناريوهات محادثات مختلفة.",
    category: "أدوات إبداعية",
    trending: true,
    language: "الإنجليزية",
    websiteLink: "https://prankshit.com/",
    icon: "/images/websites/prankshit.png",
    screenshots: ["/images/blog/apps-collection.jpg", "/images/blog/apps-collection.jpg"],
    features: [
      "إنشاء محادثات تبدو واقعية بين شخصيات مختلفة",
      "تخصيص أسماء وصور الأشخاص في المحادثة",
      "إمكانية إضافة رموز تعبيرية وصور في المحادثة",
      "حفظ المحادثة كصورة ومشاركتها على وسائل التواصل الاجتماعي",
      "واجهة سهلة الاستخدام وبديهية",
    ],
    usage: [
      "قم بزيارة موقع Prankshit",
      "اختر نوع المحادثة التي ترغب بإنشائها",
      "أضف أسماء وصور الأشخاص المشاركين في المحادثة",
      "أدخل نص المحادثة لكل شخص",
      "قم بحفظ المحادثة ومشاركتها",
    ],
    article: `
      <h2>موقع إنشاء محادثة وهمية: أداة مبتكرة لإنشاء محادثات واقعية</h2>
      
      <p>في عصر التواصل الرقمي، أصبحت المحادثات النصية جزءًا أساسيًا من تفاعلاتنا اليومية. يأتي موقع Prankshit كأداة مبتكرة تتيح للمستخدمين إنشاء محادثات وهمية تبدو واقعية بين شخصيات مختلفة، مما يفتح آفاقًا جديدة للإبداع والترفيه والتعليم.</p>
      
      <h3>ما هو موقع إنشاء محادثة وهمية؟</h3>
      
      <p>موقع Prankshit هو منصة عبر الإنترنت تتيح للمستخدمين إنشاء محادثات نصية وهمية تحاكي تطبيقات المراسلة الشهيرة مثل WhatsApp وMessenger وiMessage وغيرها. يمكن للمستخدمين تخصيص كل جانب من جوانب المحادثة، بدءًا من أسماء المشاركين وصورهم وصولاً إلى محتوى الرسائل وتوقيتها.</p>
      
      <h3>مميزات موقع إنشاء محادثة وهمية</h3>
      
      <p><strong>1. محاكاة دقيقة لتطبيقات المراسلة:</strong> يوفر الموقع قوالب تحاكي بدقة واجهة تطبيقات المراسلة الشهيرة، مما يجعل المحادثات المنشأة تبدو واقعية تمامًا.</p>
      
      <p><strong>2. تخصيص شامل:</strong> يمكن للمستخدمين تخصيص جميع عناصر المحادثة، بما في ذلك:</p>
      <ul>
        <li>أسماء المشاركين في المحادثة</li>
        <li>صور الملفات الشخصية</li>
        <li>محتوى الرسائل</li>
        <li>توقيت إرسال كل رسالة</li>
        <li>حالة القراءة والاستلام</li>
        <li>إشعارات الكتابة</li>
      </ul>
      
      <p><strong>3. دعم للوسائط المتعددة:</strong> يمكن إضافة صور ورموز تعبيرية وملصقات إلى المحادثة، مما يزيد من واقعيتها وتنوعها.</p>
      
      <p><strong>4. سهولة المشاركة:</strong> بعد إنشاء المحادثة، يمكن حفظها كصورة ومشاركتها بسهولة على منصات التواصل الاجتماعي أو إرسالها مباشرة للأصدقاء.</p>
      
      <p><strong>5. واجهة سهلة الاستخدام:</strong> تم تصميم الموقع ليكون سهل الاستخدام، حتى للمبتدئين، مع واجهة بديهية تسمح بإنشاء محادثات معقدة بسرعة وسهولة.</p>
      
      <h3>استخدامات موقع إنشاء محادثة وهمية</h3>
      
      <p>يمكن استخدام موقع إنشاء محادثة وهمية في مجموعة متنوعة من السيناريوهات:</p>
      
      <p><strong>1. المحتوى الترفيهي:</strong> إنشاء محادثات مضحكة أو ساخرة لمشاركتها مع الأصدقاء أو على منصات التواصل الاجتماعي.</p>
      
      <p><strong>2. المحتوى التعليمي:</strong> إنشاء سيناريوهات محادثات لتوضيح مفاهيم معينة أو لاستخدامها في المواد التعليمية.</p>
      
      <p><strong>3. السرد القصصي:</strong> استخدام المحادثات كوسيلة لسرد قصص أو روايات بطريقة تفاعلية وعصرية.</p>
      
      <p><strong>4. التسويق والإعلان:</strong> إنشاء محادثات توضح كيفية تفاعل العملاء مع المنتجات أو الخدمات.</p>
      
      <h3>كيفية استخدام موقع إنشاء محادثة وهمية</h3>
      
      <p>استخدام موقع Prankshit سهل وبسيط:</p>
      
      <ol>
        <li><strong>اختيار القالب:</strong> ابدأ باختيار قالب تطبيق المراسلة الذي ترغب في محاكاته (WhatsApp، Messenger، iMessage، إلخ).</li>
        <li><strong>إعداد المشاركين:</strong> أضف أسماء وصور الأشخاص المشاركين في المحادثة.</li>
        <li><strong>إنشاء المحادثة:</strong> أضف الرسائل لكل مشارك، مع تحديد التوقيت وحالة القراءة لكل رسالة.</li>
        <li><strong>إضافة الوسائط:</strong> أضف الصور والرموز التعبيرية والملصقات حسب الحاجة.</li>
        <li><strong>معاينة وتعديل:</strong> راجع المحادثة وقم بتعديلها حتى تصل إلى النتيجة المطلوبة.</li>
        <li><strong>حفظ ومشاركة:</strong> احفظ المحادثة كصورة وشاركها مع الآخرين.</li>
      </ol>
      
      <h3>الخلاصة</h3>
      
      <p>موقع إنشاء محادثة وهمية هو أداة مبتكرة تفتح آفاقًا جديدة للإبداع والتعبير في العصر الرقمي. سواء كنت تستخدمه لإنشاء محتوى ترفيهي، أو لأغراض تعليمية، أو للسرد القصصي، فإن هذا الموقع يوفر لك الأدوات اللازمة لإنشاء محادثات واقعية ومقنعة بسهولة وسرعة.</p>
      
      <p>مع الالتزام بالاستخدام المسؤول، يمكن لهذه الأداة أن تكون إضافة قيمة لمجموعة أدواتك الإبداعية والتواصلية في العالم الرقمي.</p>
    `,
  },
  {
    id: "3",
    title: "إنشاء هوية مزورة",
    description:
      "موقع لإنشاء هويات افتراضية للاستخدام في الاختبارات والتجارب. يمكن استخدامه لأغراض تعليمية وتجريبية في مجال تطوير البرمجيات.",
    category: "أدوات",
    trending: false,
    language: "الإنجليزية",
    websiteLink: "https://www.idcreator.com/",
    icon: "/images/websites/idcreator.png",
    screenshots: ["/images/blog/apps-collection.jpg", "/images/blog/apps-collection.jpg"],
    features: [
      "إنشاء بيانات شخصية افتراضية كاملة",
      "توليد أسماء وعناوين وأرقام هواتف عشوائية",
      "إمكانية تخصيص البيانات حسب الدولة واللغة",
      "توليد صور شخصية افتراضية",
      "تصدير البيانات بصيغ مختلفة",
    ],
    usage: [
      "قم بزيارة موقع IDCreator",
      "حدد نوع الهوية التي ترغب بإنشائها",
      "اختر الدولة واللغة المطلوبة",
      "قم بتخصيص البيانات حسب احتياجاتك",
      "قم بتصدير الهوية الافتراضية",
    ],
    article: `
      <h2>موقع إنشاء هوية مزورة: أداة للبيانات الافتراضية للاختبارات والتجارب</h2>
      
      <p>في عالم تطوير البرمجيات واختبار الأنظمة، غالبًا ما تكون هناك حاجة لبيانات واقعية لاختبار التطبيقات والأنظمة. يأتي موقع IDCreator كحل مثالي لهذه المشكلة، حيث يوفر أداة لإنشاء هويات افتراضية كاملة يمكن استخدامها في الاختبارات والتجارب دون المساس بخصوصية الأشخاص الحقيقيين.</p>
      
      <h3>ما هو موقع إنشاء هوية مزورة؟</h3>
      
      <p>موقع IDCreator هو منصة عبر الإنترنت تتيح للمستخدمين إنشاء بيانات شخصية افتراضية كاملة، بما في ذلك الاسم والعنوان ورقم الهاتف والبريد الإلكتروني وتاريخ الميلاد وغيرها من المعلومات. هذه البيانات ليست حقيقية ولكنها تبدو واقعية وتتبع القواعد والأنماط المعتادة للبيانات الشخصية.</p>
      
      <h3>مميزات موقع إنشاء هوية مزورة</h3>
      
      <p><strong>1. توليد بيانات شاملة:</strong> يوفر الموقع إمكانية توليد مجموعة كاملة من البيانات الشخصية، بما في ذلك:</p>
      <ul>
        <li>الاسم الكامل</li>
        <li>العنوان (الشارع، المدينة، الرمز البريدي، الدولة)</li>
        <li>رقم الهاتف</li>
        <li>البريد الإلكتروني</li>
        <li>تاريخ الميلاد</li>
        <li>رقم بطاقة الهوية أو جواز السفر</li>
        <li>معلومات بطاقة الائتمان (للاختبارات فقط)</li>
      </ul>
      
      <p><strong>2. تخصيص حسب الدولة واللغة:</strong> يمكن تخصيص البيانات المولدة حسب الدولة واللغة، مما يضمن أن تكون البيانات متوافقة مع الأنماط والقواعد المحلية.</p>
      
      <p><strong>3. توليد صور شخصية افتراضية:</strong> يوفر الموقع إمكانية توليد صور شخصية افتراضية لاستخدامها مع الهويات المولدة، مما يجعل البيانات أكثر اكتمالاً.</p>
      
      <p><strong>4. تصدير البيانات بصيغ مختلفة:</strong> يمكن تصدير البيانات المولدة بصيغ مختلفة مثل CSV أو JSON أو XML، مما يسهل استخدامها في مختلف التطبيقات والأنظمة.</p>
      
      <p><strong>5. واجهة سهلة الاستخدام:</strong> يتميز الموقع بواجهة بسيطة وسهلة الاستخدام، مما يجعل عملية إنشاء الهويات الافتراضية سريعة وفعالة.</p>
      
      <h3>استخدامات موقع إنشاء هوية مزورة</h3>
      
      <p>يمكن استخدام موقع إنشاء هوية مزورة في مجموعة متنوعة من السيناريوهات المشروعة:</p>
      
      <p><strong>1. تطوير البرمجيات واختبارها:</strong> استخدام البيانات الافتراضية لاختبار التطبيقات والأنظمة دون استخدام بيانات حقيقية.</p>
      
      <p><strong>2. التدريب والتعليم:</strong> استخدام الهويات الافتراضية في سيناريوهات التدريب والتعليم، مثل تدريب موظفي خدمة العملاء أو تعليم الطلاب كيفية التعامل مع البيانات الشخصية.</p>
      
      <p><strong>3. تصميم واجهات المستخدم:</strong> استخدام البيانات الافتراضية في تصميم واجهات المستخدم وإنشاء نماذج أولية للتطبيقات.</p>
      
      <h3>كيفية استخدام موقع إنشاء هوية مزورة</h3>
      
      <p>استخدام موقع IDCreator سهل وبسيط:</p>
      
      <ol>
        <li><strong>الوصول إلى الموقع:</strong> قم بزيارة موقع IDCreator عبر متصفحك المفضل.</li>
        <li><strong>تحديد نوع الهوية:</strong> اختر نوع الهوية التي ترغب في إنشائها (شخصية، تجارية، إلخ).</li>
        <li><strong>تخصيص الإعدادات:</strong> حدد الدولة واللغة والإعدادات الأخرى حسب احتياجاتك.</li>
        <li><strong>توليد البيانات:</strong> انقر على زر "توليد" لإنشاء الهوية الافتراضية.</li>
        <li><strong>تخصيص البيانات (اختياري):</strong> يمكنك تعديل أي من البيانات المولدة حسب احتياجاتك.</li>
        <li><strong>تصدير البيانات:</strong> اختر صيغة التصدير المناسبة واحفظ البيانات لاستخدامها في تطبيقك أو نظامك.</li>
      </ol>
      
      <h3>الاستخدام المسؤول</h3>
      
      <p>من المهم التأكيد على أن موقع إنشاء هوية مزورة مصمم للاستخدام في الأغراض المشروعة فقط، مثل تطوير البرمجيات واختبارها والتدريب والتعليم. يجب عدم استخدام الهويات الافتراضية المولدة لأغراض احتيالية أو غير قانونية.</p>
      
      <h3>الخلاصة</h3>
      
      <p>موقع إنشاء هوية مزورة هو أداة قيمة للمطورين والمختبرين والمعلمين وغيرهم ممن يحتاجون إلى بيانات افتراضية واقعية لأغراض مشروعة. مع الالتزام بالاستخدام المسؤول والأخلاقي، يمكن لهذه الأداة أن تكون إضافة قيمة لمجموعة أدواتك في مجال تطوير البرمجيات واختبارها.</p>
    `,
  },
  {
    id: "4",
    title: "مشاهدة الستوري بشكل سري",
    description:
      "موقع يتيح لك مشاهدة قصص انستقرام دون ترك أثر. مفيد لمتابعة المحتوى بخصوصية ودون إعلام صاحب المحتوى بمشاهدتك.",
    category: "أدوات السوشيال ميديا",
    trending: true,
    language: "الإنجليزية",
    websiteLink: "https://www.igram.com/",
    icon: "/images/websites/igram.png",
    screenshots: ["/images/websites/igram.png", "/images/websites/igram.png"],
    features: [
      "مشاهدة قصص انستقرام بشكل مخفي",
      "عدم ظهور اسمك في قائمة المشاهدين",
      "إمكانية تحميل القصص والمنشورات",
      "واجهة سهلة الاستخدام",
      "لا يتطلب تسجيل الدخول أو إنشاء حساب",
    ],
    usage: [
      "قم بزيارة موقع IGram",
      "أدخل اسم المستخدم الذي ترغب بمشاهدة قصصه",
      "اختر القصة التي ترغب بمشاهدتها",
      "استمتع بمشاهدة القصص بشكل سري",
    ],
    article: `
      <h2>موقع مشاهدة الستوري بشكل سري: تصفح قصص انستقرام بخصوصية تامة</h2>
      
      <p>في عصر وسائل التواصل الاجتماعي، أصبحت ميزة القصص (Stories) من أكثر الميزات استخدامًا على منصات مثل انستقرام. ومع ذلك، قد يرغب البعض في مشاهدة هذه القصص دون ترك أثر أو إعلام صاحب المحتوى بمشاهدتهم. هنا يأتي دور موقع IGram الذي يتيح للمستخدمين مشاهدة قصص انستقرام بشكل سري.</p>
      
      <h3>ما هو موقع مشاهدة الستوري بشكل سري؟</h3>
      
      <p>موقع IGram هو منصة عبر الإنترنت تتيح للمستخدمين مشاهدة قصص انستقرام دون تسجيل الدخول إلى حساباتهم ودون ظهور أسمائهم في قائمة المشاهدين. بالإضافة إلى ذلك، يوفر الموقع إمكانية تحميل القصص والمنشورات للاطلاع عليها لاحقًا.</p>
      
      <h3>مميزات موقع مشاهدة الستوري بشكل سري</h3>
      
      <p><strong>1. المشاهدة المخفية:</strong> يتيح الموقع مشاهدة قصص انستقرام دون ظهور اسمك في قائمة المشاهدين، مما يوفر خصوصية تامة.</p>
      
      <p><strong>2. لا حاجة لتسجيل الدخول:</strong> يمكنك استخدام الموقع دون الحاجة لتسجيل الدخول إلى حساب انستقرام الخاص بك، مما يوفر طبقة إضافية من الخصوصية.</p>
      
      <p><strong>3. تحميل القصص والمنشورات:</strong> يوفر الموقع إمكانية تحميل القصص والمنشورات لمشاهدتها لاحقًا دون الحاجة للاتصال بالإنترنت.</p>
      
      <p><strong>4. واجهة سهلة الاستخدام:</strong> يتميز الموقع بواجهة بسيطة وسهلة الاستخدام، مما يجعل تجربة المستخدم سلسة وفعالة.</p>
      
      <h3>كيفية استخدام موقع مشاهدة الستوري بشكل سري</h3>
      
      <p>استخدام موقع IGram سهل وبسيط:</p>
      
      <ol>
        <li><strong>الوصول إلى الموقع:</strong> قم بزيارة موقع IGram عبر متصفحك المفضل.</li>
        <li><strong>إدخال اسم المستخدم:</strong> أدخل اسم مستخدم انستقرام الذي ترغب في مشاهدة قصصه في مربع البحث.</li>
        <li><strong>اختيار المحتوى:</strong> بعد ظهور نتائج البحث، اختر القصة أو المنشور الذي ترغب في مشاهدته.</li>
        <li><strong>المشاهدة أو التحميل:</strong> يمكنك مشاهدة المحتوى مباشرة على الموقع أو تحميله لمشاهدته لاحقًا.</li>
      </ol>
      
      <h3>الاعتبارات الأخلاقية والقانونية</h3>
      
      <p>على الرغم من أن موقع مشاهدة الستوري بشكل سري يوفر خدمة مفيدة للعديد من المستخدمين، إلا أنه من المهم مراعاة بعض الاعتبارات الأخلاقية والقانونية:</p>
      
      <ul>
        <li><strong>احترام الخصوصية:</strong> استخدم الموقع بمسؤولية واحترم خصوصية الآخرين.</li>
        <li><strong>حقوق الملكية الفكرية:</strong> لا تستخدم المحتوى الذي تشاهده أو تحمله لأغراض تجارية دون إذن صاحبه.</li>
        <li><strong>شروط الخدمة:</strong> قد يتعارض استخدام مثل هذه المواقع مع شروط خدمة انستقرام، لذا استخدمها على مسؤوليتك الخاصة.</li>
      </ul>
      
      <h3>الخلاصة</h3>
      
      <p>موقع مشاهدة الستوري بشكل سري يوفر طريقة سهلة وفعالة لمشاهدة قصص انستقرام دون ترك أثر. مع واجهة سهلة الاستخدام وميزات مثل تحميل المحتوى، يمكن لهذا الموقع أن يكون أداة مفيدة للعديد من المستخدمين.</p>
      
      <p>ومع ذلك، من المهم استخدام هذه الخدمة بمسؤولية واحترام خصوصية الآخرين وحقوق الملكية الفكرية. استمتع بمشاهدة المحتوى الذي تفضله بخصوصية تامة، ولكن تذكر دائمًا أن تفعل ذلك بطريقة أخلاقية ومسؤولة.</p>
    `,
  },
]

export async function generateMetadata({ params }: { params: { id: string } }) {
  const website = websitesData.find((website) => website.id === params.id)

  if (!website) {
    return {
      title: "موقع غير موجود | Pasha_jord",
      description: "عذراً، الموقع المطلوب غير موجود",
    }
  }

  return {
    title: `${website.title} | Pasha_jord`,
    description: website.description,
  }
}

export default function WebsiteDetailPage({ params }: { params: { id: string } }) {
  const website = websitesData.find((website) => website.id === params.id)

  if (!website) {
    return (
      <div className="min-h-screen flex flex-col tech-pattern">
        <Navbar />
        <main className="flex-1 container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">عذراً، الموقع المطلوب غير موجود</h1>
            <p className="text-lg text-muted-foreground mb-8">لم نتمكن من العثور على الموقع الذي تبحث عنه</p>
            <Link href="/websites">
              <Button>
                العودة إلى صفحة المواقع
                <ChevronRight className="mr-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="flex flex-wrap gap-2 items-center text-sm text-muted-foreground mb-4">
                <Link href="/websites" className="hover:text-primary">
                  المواقع
                </Link>
                <ChevronRight className="h-4 w-4" />
                <span>{website.category}</span>
                <ChevronRight className="h-4 w-4" />
                <span className="truncate max-w-[200px]">{website.title}</span>
              </div>
              <div className="flex items-center gap-6">
                <div className="relative h-24 w-24 rounded-xl bg-primary/10 flex items-center justify-center overflow-hidden">
                  <Image
                    src={website.icon || "/placeholder.svg"}
                    alt={website.title}
                    width={80}
                    height={80}
                    className="rounded-md"
                  />
                </div>
                <div>
                  <h1 className="text-4xl font-bold mb-2">{website.title}</h1>
                  <div className="flex items-center gap-4">
                    {website.trending && (
                      <div className="flex items-center text-orange-500">
                        <TrendingUp className="h-5 w-5 ml-1" />
                        <span className="font-medium">رائج</span>
                      </div>
                    )}
                    <span className="text-sm bg-muted px-2 py-1 rounded-full">{website.language}</span>
                    <span className="text-sm text-muted-foreground">{website.category}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <Card className="p-6 mb-8">
              <h2 className="text-2xl font-bold mb-4">وصف الموقع</h2>
              <p className="mb-6">{website.description}</p>

              <h3 className="text-xl font-bold mb-3">المميزات الرئيسية:</h3>
              <ul className="list-disc list-inside space-y-2 mr-4 mb-6">
                {website.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>

              <h3 className="text-xl font-bold mb-3">كيفية الاستخدام:</h3>
              <ol className="list-decimal list-inside space-y-2 mr-4 mb-6">
                {website.usage.map((step, index) => (
                  <li key={index}>{step}</li>
                ))}
              </ol>

              <div className="mt-6">
                <CountdownButton href={website.websiteLink} initialSeconds={15}>
                  زيارة الموقع
                </CountdownButton>
                <p className="text-center text-sm text-muted-foreground mt-2">سيتم تفعيل الرابط بعد 15 ثانية</p>
              </div>
            </Card>

            <AdBanner />

            <div className="mt-8">
              <h2 className="text-2xl font-bold mb-6">مقال عن الموقع</h2>
              <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
                <Image src={website.icon || "/placeholder.svg"} alt={website.title} fill className="object-contain" />
              </div>
              <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                {website.screenshots.map((screenshot, index) => (
                  <div key={index} className="rounded-lg overflow-hidden">
                    <Image
                      src={screenshot || "/placeholder.svg"}
                      alt={`${website.title} Screenshot ${index + 1}`}
                      width={600}
                      height={300}
                      className="w-full h-auto object-cover"
                    />
                  </div>
                ))}
              </div>
              <div
                className="prose prose-lg dark:prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: website.article }}
              />
            </div>

            <AdBanner />

            <div className="mt-12 pt-8 border-t">
              <h3 className="text-2xl font-bold mb-6">مواقع ذات صلة</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {websitesData
                  .filter((relatedWebsite) => relatedWebsite.id !== website.id)
                  .slice(0, 3)
                  .map((relatedWebsite) => (
                    <Link key={relatedWebsite.id} href={`/websites/${relatedWebsite.id}`} className="block">
                      <div className="bg-card rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                        <div className="p-4">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="relative h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
                              <Image
                                src={relatedWebsite.icon || "/placeholder.svg"}
                                alt={relatedWebsite.title}
                                width={40}
                                height={40}
                                className="object-contain"
                              />
                            </div>
                            <div>
                              <h4 className="font-bold">{relatedWebsite.title}</h4>
                              <p className="text-xs text-muted-foreground">{relatedWebsite.category}</p>
                            </div>
                          </div>
                          <p className="text-sm line-clamp-2">{relatedWebsite.description}</p>
                          <div className="flex justify-between items-center">
                            {relatedWebsite.trending && (
                              <div className="flex items-center text-orange-500">
                                <TrendingUp className="h-4 w-4 ml-1" />
                                <span className="text-sm">رائج</span>
                              </div>
                            )}
                            {!relatedWebsite.trending && <div></div>}
                            <Button variant="ghost" size="sm">
                              التفاصيل
                              <ChevronRight className="mr-1 h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
