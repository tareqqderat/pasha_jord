import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Globe, ChevronRight, TrendingUp, Filter, ExternalLink } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "المواقع | Pasha_jord",
  description: "استكشف أفضل المواقع المفيدة مع شروحات مفصلة",
}

export default function WebsitesPage() {
  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl font-bold">أفضل المواقع</h1>
              <p className="text-xl text-muted-foreground">
                استكشف مجموعة متنوعة من المواقع المفيدة مع شروحات مفصلة لكيفية استخدامها
              </p>
              <div className="relative max-w-md mx-auto mt-8">
                <Search className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input type="search" placeholder="ابحث عن موقع..." className="pr-10 py-6" />
              </div>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Filters */}
        <section className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              <h2 className="font-medium">تصفية النتائج:</h2>
            </div>
            <div className="flex flex-wrap gap-4">
              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="التصنيف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع التصنيفات</SelectItem>
                  <SelectItem value="photo">تحرير الصور</SelectItem>
                  <SelectItem value="social">السوشيال ميديا</SelectItem>
                  <SelectItem value="tools">أدوات</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="اللغة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع اللغات</SelectItem>
                  <SelectItem value="arabic">العربية</SelectItem>
                  <SelectItem value="english">الإنجليزية</SelectItem>
                  <SelectItem value="both">متعدد اللغات</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="الترتيب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">الأحدث</SelectItem>
                  <SelectItem value="popular">الأكثر شعبية</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* Websites Grid */}
        <section className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <WebsiteCard
              id={1}
              title="Pixverse"
              description="موقع مميز لتحرير الصور وإضافة تأثيرات احترافية. يوفر أدوات متقدمة لتعديل الصور بشكل احترافي وإنشاء تصاميم مميزة."
              category="تحرير الصور"
              trending={true}
              websiteLink="https://pixverse.ai/"
              icon="/images/apps/pixverse.png"
            />
            <WebsiteCard
              id={2}
              title="إنشاء محادثة وهمية"
              description="موقع يتيح لك إنشاء محادثات وهمية بين شخصيات مختلفة. مفيد لإنشاء محتوى ترفيهي أو تعليمي وإنشاء سيناريوهات محادثات مختلفة."
              category="أدوات إبداعية"
              trending={true}
              websiteLink="https://prankshit.com/"
              icon="/images/websites/prankshit.png"
            />
            <WebsiteCard
              id={3}
              title="إنشاء هوية مزورة"
              description="موقع لإنشاء هويات افتراضية للاستخدام في الاختبارات والتجارب. يمكن استخدامه لأغراض تعليمية وتجريبية في مجال تطوير البرمجيات."
              category="أدوات"
              trending={false}
              websiteLink="https://www.idcreator.com/"
              icon="/images/websites/idcreator.png"
            />
            <WebsiteCard
              id={4}
              title="مشاهدة الستوري بشكل سري"
              description="موقع يتيح لك مشاهدة قصص انستقرام دون ترك أثر. مفيد لمتابعة المحتوى بخصوصية ودون إعلام صاحب المحتوى بمشاهدتك."
              category="أدوات السوشيال ميديا"
              trending={true}
              websiteLink="https://www.igram.com/"
              icon="/images/websites/igram.png"
            />
          </div>
        </section>

        <AdBanner />

        {/* Website Details */}
        <section className="container mx-auto px-4 py-12">
          <h2 className="text-3xl font-bold mb-8">تفاصيل المواقع</h2>

          <div className="space-y-12">
            <div className="bg-card rounded-lg p-6 shadow-sm" id="website-1">
              <h3 className="text-2xl font-bold mb-4">Pixverse</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    موقع Pixverse هو منصة متكاملة لتحرير الصور عبر الإنترنت، يوفر مجموعة واسعة من الأدوات والفلاتر
                    لتحسين صورك وإضافة تأثيرات خاصة. يتميز الموقع بواجهة سهلة الاستخدام وأدوات احترافية تناسب المبتدئين
                    والمحترفين.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>تحرير الصور مباشرة عبر المتصفح دون الحاجة لتثبيت برامج</li>
                    <li>مجموعة متنوعة من الفلاتر والتأثيرات الاحترافية</li>
                    <li>أدوات متقدمة لتعديل الألوان والإضاءة والتباين</li>
                    <li>إمكانية إضافة نصوص وملصقات للصور</li>
                    <li>حفظ وتصدير الصور بصيغ مختلفة وبجودة عالية</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>قم بزيارة موقع Pixverse</li>
                    <li>ارفع الصورة التي ترغب بتعديلها</li>
                    <li>استخدم الأدوات المتاحة لتحرير الصورة</li>
                    <li>قم بحفظ الصورة بعد الانتهاء من التعديل</li>
                  </ol>
                  <a href="https://pixverse.ai/" target="_blank" rel="noopener noreferrer">
                    <Button>
                      زيارة الموقع
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <Globe className="h-16 w-16 text-primary mx-auto mb-4" />
                    <div className="flex items-center justify-center mb-2">
                      {true && (
                        <div className="flex items-center text-orange-500 mb-2">
                          <TrendingUp className="h-5 w-5 ml-1" />
                          <span className="text-sm font-medium">رائج</span>
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">اللغة: الإنجليزية</p>
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: تحرير الصور</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=600&text=Pixverse Website Screenshot 1"
                    alt="Pixverse Website Screenshot 1"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=600&text=Pixverse Website Screenshot 2"
                    alt="Pixverse Website Screenshot 2"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm" id="website-2">
              <h3 className="text-2xl font-bold mb-4">إنشاء محادثة وهمية</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    موقع Prankshit هو أداة مبتكرة تتيح لك إنشاء محادثات وهمية بين شخصيات مختلفة. يمكنك استخدامه لإنشاء
                    محتوى ترفيهي أو تعليمي من خلال محاكاة محادثات بين أشخاص مختلفين.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>إنشاء محادثات تبدو واقعية بين شخصيات مختلفة</li>
                    <li>تخصيص أسماء وصور الأشخاص في المحادثة</li>
                    <li>إمكانية إضافة رموز تعبيرية وصور في المحادثة</li>
                    <li>حفظ المحادثة كصورة ومشاركتها على وسائل التواصل الاجتماعي</li>
                    <li>واجهة سهلة الاستخدام وبديهية</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>قم بزيارة موقع Prankshit</li>
                    <li>اختر نوع المحادثة التي ترغب بإنشائها</li>
                    <li>أضف أسماء وصور الأشخاص المشاركين في المحادثة</li>
                    <li>أدخل نص المحادثة لكل شخص</li>
                    <li>قم بحفظ المحادثة ومشاركتها</li>
                  </ol>
                  <a href="https://prankshit.com/" target="_blank" rel="noopener noreferrer">
                    <Button>
                      زيارة الموقع
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <Globe className="h-16 w-16 text-primary mx-auto mb-4" />
                    <div className="flex items-center justify-center mb-2">
                      <div className="flex items-center text-orange-500 mb-2">
                        <TrendingUp className="h-5 w-5 ml-1" />
                        <span className="text-sm font-medium">رائج</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">اللغة: الإنجليزية</p>
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: أدوات إبداعية</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=600&text=Fake Chat Screenshot 1"
                    alt="Fake Chat Screenshot 1"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=600&text=Fake Chat Screenshot 2"
                    alt="Fake Chat Screenshot 2"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm" id="website-3">
              <h3 className="text-2xl font-bold mb-4">إنشاء هوية مزورة</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    موقع IDCreator هو أداة تتيح لك إنشاء هويات افتراضية للاستخدام في الاختبارات والتجارب. يمكن استخدامه
                    لأغراض تعليمية وتجريبية في مجال تطوير البرمجيات وتصميم واجهات المستخدم.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>إنشاء بيانات شخصية افتراضية كاملة</li>
                    <li>توليد أسماء وعناوين وأرقام هواتف عشوائية</li>
                    <li>إمكانية تخصيص البيانات حسب الدولة واللغة</li>
                    <li>توليد صور شخصية افتراضية</li>
                    <li>تصدير البيانات بصيغ مختلفة</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>قم بزيارة موقع IDCreator</li>
                    <li>حدد نوع الهوية التي ترغب بإنشائها</li>
                    <li>اختر الدولة واللغة المطلوبة</li>
                    <li>قم بتخصيص البيانات حسب احتياجاتك</li>
                    <li>قم بتصدير الهوية الافتراضية</li>
                  </ol>
                  <a href="https://www.idcreator.com/" target="_blank" rel="noopener noreferrer">
                    <Button>
                      زيارة الموقع
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <Globe className="h-16 w-16 text-primary mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground">اللغة: الإنجليزية</p>
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: أدوات</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=600&text=Fake ID Screenshot 1"
                    alt="Fake ID Screenshot 1"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=600&text=Fake ID Screenshot 2"
                    alt="Fake ID Screenshot 2"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm" id="website-4">
              <h3 className="text-2xl font-bold mb-4">مشاهدة الستوري بشكل سري</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    موقع IGram هو أداة تتيح لك مشاهدة قصص انستقرام دون ترك أثر. يمكنك استخدامه لمتابعة المحتوى بخصوصية
                    ودون إعلام صاحب المحتوى بمشاهدتك للقصص.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>مشاهدة قصص انستقرام بشكل مخفي</li>
                    <li>عدم ظهور اسمك في قائمة المشاهدين</li>
                    <li>إمكانية تحميل القصص والمنشورات</li>
                    <li>واجهة سهلة الاستخدام</li>
                    <li>لا يتطلب تسجيل الدخول أو إنشاء حساب</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>قم بزيارة موقع IGram</li>
                    <li>أدخل اسم المستخدم الذي ترغب بمشاهدة قصصه</li>
                    <li>اختر القصة التي ترغب بمشاهدتها</li>
                    <li>استمتع بمشاهدة القصص بشكل سري</li>
                  </ol>
                  <a href="https://www.igram.com/" target="_blank" rel="noopener noreferrer">
                    <Button>
                      زيارة الموقع
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <div className="relative h-16 w-16 mx-auto mb-4">
                      <Image src="/images/websites/igram.png" alt="IGram Logo" fill className="object-contain" />
                    </div>
                    <div className="flex items-center justify-center mb-2">
                      <div className="flex items-center text-orange-500 mb-2">
                        <TrendingUp className="h-5 w-5 ml-1" />
                        <span className="text-sm font-medium">رائج</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">اللغة: الإنجليزية</p>
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: أدوات السوشيال ميديا</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/websites/igram.png"
                    alt="Story Viewer Screenshot 1"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/websites/igram.png"
                    alt="Story Viewer Screenshot 2"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <AdBanner />
      </main>

      <Footer />
    </div>
  )
}

// Update the WebsiteCard function to use the correct images
function WebsiteCard({
  id,
  title,
  description,
  category,
  trending,
  websiteLink,
  icon = <Globe className="h-8 w-8 text-primary" />,
}: {
  id: number
  title: string
  description: string
  category: string
  trending: boolean
  websiteLink: string
  icon?: React.ReactNode | string
}) {
  // Use the actual image path for the icon
  const iconSrc =
    typeof icon === "string"
      ? icon
      : title === "Pixverse"
        ? "/images/apps/pixverse.png"
        : title === "إنشاء محادثة وهمية"
          ? "/images/websites/prankshit.png"
          : title === "إنشاء هوية مزورة"
            ? "/images/websites/idcreator.png"
            : title === "مشاهدة الستوري بشكل سري"
              ? "/images/websites/igram.png"
              : "/placeholder.svg?height=50&width=50&text=" + title.substring(0, 2)

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex gap-4 items-center">
            <div className="relative h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
              {typeof icon === "string" ? (
                <Image
                  src={iconSrc || "/placeholder.svg"}
                  alt={title}
                  width={48}
                  height={48}
                  className="object-contain"
                />
              ) : (
                icon
              )}
            </div>
            <div>
              <CardTitle>{title}</CardTitle>
              <CardDescription>{category}</CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="line-clamp-3">{description}</p>

        <div className="flex justify-between items-center">
          {trending && (
            <div className="flex items-center text-orange-500">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">رائج</span>
            </div>
          )}
          {!trending && <div></div>}
          <span className="text-xs bg-muted px-2 py-1 rounded-full">{category}</span>
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/websites/${id}`} className="w-full">
          <Button className="w-full">
            التفاصيل
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
