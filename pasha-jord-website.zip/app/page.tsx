import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"
import Link from "next/link"
import { Smartphone, Globe, MessageCircle, ChevronRight, Star, TrendingUp, Instagram, Youtube } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="container mx-auto px-4 py-12 md:py-24 flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1 space-y-6 text-center md:text-right">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              <span className="text-primary">Pasha_jord</span> لمحبي التكنولوجيا
            </h1>
            <p className="text-xl text-muted-foreground">مرجعك الأول لأحدث التطبيقات والمواقع وبوتات تلجرام</p>
            <div className="flex flex-wrap gap-4 justify-center md:justify-end">
              <Link href="/apps">
                <Button size="lg">
                  استكشف المحتوى
                  <ChevronRight className="mr-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="https://www.instagram.com/pasha_jord/" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" size="lg">
                  تابعنا على السوشيال ميديا
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex-1 flex flex-col items-center md:items-start">
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden">
              <Image src="/logo.png" alt="Pasha_jord Logo" fill className="object-contain" priority />
            </div>
            <div className="flex gap-4 mt-4 justify-center">
              <a
                href="https://www.instagram.com/pasha_jord/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80"
              >
                <Instagram className="h-8 w-8" />
                <span className="sr-only">Instagram</span>
              </a>
              <a
                href="https://youtube.com/@pasha_jord?si=wmEesdZh_5FkZmRl"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80"
              >
                <Youtube className="h-8 w-8" />
                <span className="sr-only">YouTube</span>
              </a>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Categories Section */}
        <section className="container mx-auto px-4 py-12">
          <h2 className="text-3xl font-bold text-center mb-12">استكشف عالم التكنولوجيا</h2>

          <Tabs defaultValue="apps" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="apps" className="text-lg py-3">
                <Smartphone className="ml-2 h-5 w-5" />
                تطبيقات
              </TabsTrigger>
              <TabsTrigger value="websites" className="text-lg py-3">
                <Globe className="ml-2 h-5 w-5" />
                مواقع
              </TabsTrigger>
              <TabsTrigger value="telegram-bots" className="text-lg py-3">
                <MessageCircle className="ml-2 h-5 w-5" />
                بوتات تلجرام
              </TabsTrigger>
            </TabsList>

            <TabsContent value="apps" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <AppCard
                  id={3}
                  title="CapCut"
                  description="تطبيق احترافي لتحرير الفيديوهات مع العديد من الأدوات والمؤثرات. مثالي لإنشاء محتوى فيديو احترافي للسوشيال ميديا."
                  category="تحرير الفيديو"
                  rating={4.9}
                  downloadLink="https://play.google.com/store/apps/details?id=com.lemon.lvoverseas"
                  icon="/images/apps/capcut.png"
                />
                <AppCard
                  id={2}
                  title="ChatGPT"
                  description="تطبيق الذكاء الاصطناعي الشهير الذي يمكنك من التحدث مع مساعد ذكي والحصول على إجابات لأسئلتك ومساعدة في مختلف المهام."
                  category="الذكاء الاصطناعي"
                  rating={4.7}
                  downloadLink="https://play.google.com/store/apps/details?id=com.openai.chatgpt"
                  icon="/images/apps/chatgpt.png"
                />
                <AppCard
                  id={1}
                  title="Pixverse"
                  description="تطبيق رائع لتحرير الصور وإضافة تأثيرات مميزة. يمكنك استخدامه لإنشاء صور احترافية بسهولة وسرعة."
                  category="تحرير الصور"
                  rating={4.8}
                  downloadLink="https://play.google.com/store/apps/details?id=com.pixverse.editor"
                  icon="/images/apps/pixverse.png"
                />
              </div>
            </TabsContent>

            <TabsContent value="websites" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <WebsiteCard
                  id={4}
                  title="مشاهدة الستوري بشكل سري"
                  description="موقع يتيح لك مشاهدة قصص انستقرام دون ترك أثر. مفيد لمتابعة المحتوى بخصوصية."
                  category="أدوات السوشيال ميديا"
                  trending={true}
                  websiteLink="https://www.igram.com/"
                  icon="/images/websites/igram.png"
                />
                <WebsiteCard
                  id={2}
                  title="إنشاء محادثة وهمية"
                  description="موقع يتيح لك إنشاء محادثات وهمية بين شخصيات مختلفة. مفيد لإنشاء محتوى ترفيهي أو تعليمي."
                  category="أدوات إبداعية"
                  trending={true}
                  websiteLink="https://prankshit.com/"
                  icon="/images/websites/prankshit.png"
                />
                <WebsiteCard
                  id={3}
                  title="إنشاء هوية مزورة"
                  description="موقع لإنشاء هويات افتراضية للاستخدام في الاختبارات والتجارب. يمكن استخدامه لأغراض تعليمية."
                  category="أدوات"
                  trending={false}
                  websiteLink="https://www.idcreator.com/"
                  icon="/images/websites/idcreator.png"
                />
                <WebsiteCard
                  id={1}
                  title="Pixverse"
                  description="موقع مميز لتحرير الصور وإضافة تأثيرات احترافية. يوفر أدوات متقدمة لتعديل الصور بشكل احترافي."
                  category="تحرير الصور"
                  trending={true}
                  websiteLink="https://pixverse.ai/"
                  icon="/images/apps/pixverse.png"
                />
              </div>
            </TabsContent>

            <TabsContent value="telegram-bots" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <TelegramBotCard
                  id={4}
                  title="ElevenLabs"
                  description="بوت تلجرام متخصص في تحويل النص إلى صوت بجودة عالية وبأصوات متعددة. مثالي لإنشاء تعليق صوتي احترافي."
                  category="الذكاء الاصطناعي"
                  isNew={true}
                  botLink="https://t.me/elevenlabsiobot"
                  icon="/images/bots/telegram-icon.png"
                />
                <TelegramBotCard
                  id={3}
                  title="Truecaller"
                  description="بوت تلجرام يساعدك في معرفة هوية المتصل ومعلومات الأرقام. يمكنك استخدامه للبحث عن أرقام الهواتف."
                  category="أدوات"
                  isNew={true}
                  botLink="https://t.me/TrueCaller_Z_Bot"
                  icon="/images/bots/telegram-icon.png"
                />
                <TelegramBotCard
                  id={5}
                  title="CCL"
                  description="بوت تلجرام متعدد الاستخدامات يوفر العديد من الأدوات المفيدة في مكان واحد. يساعدك في مختلف المهام اليومية."
                  category="أدوات متنوعة"
                  isNew={false}
                  botLink="https://t.me/kinskbot"
                  icon="/images/bots/telegram-icon.png"
                />
                <TelegramBotCard
                  id={1}
                  title="بوت تصوير الأشخاص"
                  description="بوت تلجرام يساعدك في تصوير الأشخاص بطريقة مميزة. يمكنك استخدامه لإنشاء صور شخصية احترافية."
                  category="تصوير"
                  isNew={true}
                  botLink="https://t.me/Prankstdbot"
                  icon="/images/bots/telegram-icon.png"
                />
                <TelegramBotCard
                  id={2}
                  title="بوت تحميل الفيديوهات"
                  description="بوت تلجرام يساعدك في تحميل الفيديوهات من مختلف المنصات بسهولة وسرعة. مثالي لحفظ المحتوى المفضل لديك."
                  category="تحميل"
                  isNew={false}
                  botLink="https://t.me/SaveVideoBot"
                  icon="/images/bots/telegram-icon.png"
                />
              </div>
            </TabsContent>
          </Tabs>
        </section>

        <AdBanner />

        {/* Blog Preview Section */}
        <section className="container mx-auto px-4 py-12 md:py-24">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">أحدث المقالات</h2>
            <Link href="/blog">
              <Button variant="outline">
                عرض جميع المقالات
                <ChevronRight className="mr-2 h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <BlogCard
              title="أفضل 10 تطبيقات لتحرير الصور في 2025"
              category="تطبيقات"
              date="5 مايو 2025"
              excerpt="استعراض لأفضل تطبيقات تحرير الصور المتاحة حالياً مع شرح مميزات كل منها وكيفية استخدامها للحصول على أفضل النتائج."
              slug="best-photo-editing-apps-2025"
              image="/images/blog/app-collection.png"
            />
            <BlogCard
              title="كيفية زيادة متابعينك على انستقرام في 2025"
              category="السوشيال ميديا"
              date="2 مايو 2025"
              excerpt="نصائح وإستراتيجيات فعالة لزيادة عدد متابعيك على انستقرام وتحسين التفاعل مع منشوراتك بطرق شرعية وفعالة."
              slug="increase-instagram-followers-2025"
              image="/images/blog/social-media-apps.png"
            />
            <BlogCard
              title="دليل شامل لإنشاء محتوى فيديو احترافي"
              category="إنشاء المحتوى"
              date="28 أبريل 2025"
              excerpt="خطوات تفصيلية لإنشاء محتوى فيديو احترافي باستخدام أدوات بسيطة، من مرحلة التخطيط وحتى النشر والترويج."
              slug="professional-video-content-guide"
              image="/images/blog/social-media-3d.png"
            />
          </div>
        </section>

        {/* Featured Content Section with New Images */}
        <section className="container mx-auto px-4 py-12">
          <h2 className="text-3xl font-bold text-center mb-12">محتوى مميز</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="relative h-64">
                <Image src="/images/blog/web-design-purple.png" alt="تصميم المواقع" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2">أساسيات تصميم المواقع الإلكترونية</h3>
                <p className="text-muted-foreground mb-4">
                  تعرف على أهم المبادئ والأدوات اللازمة لتصميم موقع إلكتروني احترافي يجذب الزوار ويحقق أهدافك.
                </p>
                <Link href="/blog/web-design-basics">
                  <Button variant="outline">
                    اقرأ المزيد
                    <ChevronRight className="mr-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="relative h-64">
                <Image src="/images/blog/web-development.png" alt="تطوير المواقع" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2">أدوات تطوير المواقع الحديثة</h3>
                <p className="text-muted-foreground mb-4">
                  استكشف أحدث الأدوات والتقنيات المستخدمة في تطوير المواقع الإلكترونية وكيفية الاستفادة منها في مشاريعك.
                </p>
                <Link href="/blog/modern-web-development-tools">
                  <Button variant="outline">
                    اقرأ المزيد
                    <ChevronRight className="mr-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Technology Trends Section */}
        <section className="container mx-auto px-4 py-12 md:py-24 bg-gradient-to-r from-primary/5 to-primary/10 rounded-3xl my-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">أحدث اتجاهات التكنولوجيا</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              تعرف على أحدث التطورات والاتجاهات في عالم التكنولوجيا والتطبيقات والمواقع الإلكترونية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="relative h-48 mb-4 rounded-md overflow-hidden">
                <Image src="/images/blog/web-design-interactive.png" alt="تصميم تفاعلي" fill className="object-cover" />
              </div>
              <h3 className="text-xl font-bold mb-2">تصميم المواقع التفاعلية</h3>
              <p className="text-muted-foreground">
                كيف يمكن للتصميم التفاعلي أن يحسن تجربة المستخدم ويزيد من معدلات التحويل على موقعك الإلكتروني.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="relative h-48 mb-4 rounded-md overflow-hidden">
                <Image src="/images/blog/app-collection.png" alt="تطبيقات الهاتف" fill className="object-cover" />
              </div>
              <h3 className="text-xl font-bold mb-2">تطبيقات الهاتف المحمول</h3>
              <p className="text-muted-foreground">
                استعراض لأحدث التطبيقات وكيفية الاستفادة منها في حياتك اليومية وتحسين إنتاجيتك.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="relative h-48 mb-4 rounded-md overflow-hidden">
                <Image
                  src="/images/blog/social-media-3d.png"
                  alt="وسائل التواصل الاجتماعي"
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="text-xl font-bold mb-2">استراتيجيات السوشيال ميديا</h3>
              <p className="text-muted-foreground">
                كيفية بناء استراتيجية فعالة للتواصل الاجتماعي تساعدك على الوصول إلى جمهورك المستهدف وتحقيق أهدافك.
              </p>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Newsletter Section */}
        <section className="container mx-auto px-4 py-12 md:py-24">
          <div className="bg-primary/10 rounded-2xl p-8 md:p-12">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <h2 className="text-3xl font-bold">اشترك في النشرة البريدية</h2>
              <p className="text-lg text-muted-foreground">
                احصل على آخر التحديثات حول أحدث التطبيقات والمواقع وبوتات تلجرام مباشرة إلى بريدك الإلكتروني
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  className="px-4 py-2 rounded-md border flex-1 focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <Button>اشترك الآن</Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

function AppCard({
  id,
  title,
  description,
  category,
  rating,
  downloadLink,
  icon,
}: {
  id: number
  title: string
  description: string
  category: string
  rating: number
  downloadLink: string
  icon?: string
}) {
  // استخدام الأيقونة الحقيقية أو أيقونة افتراضية
  const iconSrc = icon || "/placeholder.svg?height=50&width=50&text=App"

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="relative h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
            <Image src={iconSrc || "/placeholder.svg"} alt={title} width={48} height={48} className="object-contain" />
          </div>
          <div className="flex items-center">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
            <span className="text-sm font-medium">{rating}</span>
          </div>
        </div>
        <CardTitle className="mt-4">{title}</CardTitle>
        <CardDescription>{category}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3">{description}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/apps/${id}`} className="w-full">
          <Button variant="outline" className="w-full">
            التفاصيل
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

function WebsiteCard({
  id,
  title,
  description,
  category,
  trending,
  websiteLink,
  icon,
}: {
  id: number
  title: string
  description: string
  category: string
  trending: boolean
  websiteLink: string
  icon?: string
}) {
  // استخدام الأيقونة الحقيقية أو أيقونة افتراضية
  const iconSrc = icon || "/placeholder.svg?height=50&width=50&text=Website"

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="relative h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
            <Image src={iconSrc || "/placeholder.svg"} alt={title} width={48} height={48} className="object-contain" />
          </div>
          {trending && (
            <div className="flex items-center text-orange-500">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">رائج</span>
            </div>
          )}
        </div>
        <CardTitle className="mt-4">{title}</CardTitle>
        <CardDescription>{category}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3">{description}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/websites/${id}`} className="w-full">
          <Button variant="outline" className="w-full">
            التفاصيل
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

function TelegramBotCard({
  id,
  title,
  description,
  category,
  isNew,
  botLink,
  icon,
}: {
  id: number
  title: string
  description: string
  category: string
  isNew: boolean
  botLink: string
  icon?: string
}) {
  // استخدام الأيقونة الحقيقية أو أيقونة افتراضية
  const iconSrc = icon || "/placeholder.svg?height=50&width=50&text=Bot"

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="relative h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
            <Image src={iconSrc || "/placeholder.svg"} alt={title} width={48} height={48} className="object-contain" />
          </div>
          {isNew && <div className="bg-green-500 text-white text-xs font-medium px-2 py-1 rounded">جديد</div>}
        </div>
        <CardTitle className="mt-4">{title}</CardTitle>
        <CardDescription>{category}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3">{description}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/telegram-bots/${id}`} className="w-full">
          <Button variant="outline" className="w-full">
            التفاصيل
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

function BlogCard({
  title,
  category,
  date,
  excerpt,
  slug,
  image,
}: {
  title: string
  category: string
  date: string
  excerpt: string
  slug: string
  image?: string
}) {
  // استخدام صورة المقال الحقيقية أو صورة افتراضية حسب الفئة
  const imageSrc = image || `/placeholder.svg?height=200&width=400&text=${encodeURIComponent(category)}`

  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 bg-muted">
        <Image src={imageSrc || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <CardHeader>
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-primary">{category}</span>
          <span className="text-xs text-muted-foreground">{date}</span>
        </div>
        <CardTitle className="line-clamp-2">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3">{excerpt}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/blog/${slug}`} className="w-full">
          <Button variant="ghost" className="w-full">
            قراءة المزيد
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
