import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Star, ChevronRight } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"
import Link from "next/link"
import Image from "next/image"
import { CountdownButton } from "@/components/countdown-button"

// بيانات التطبيقات
const appsData = [
  {
    id: "1",
    title: "Pixverse",
    description:
      "تطبيق رائع لتحرير الصور وإضافة تأثيرات مميزة. يمكنك استخدامه لإنشاء صور احترافية بسهولة وسرعة. يحتوي على العديد من الفلاتر والأدوات المتقدمة التي تساعدك في تحسين صورك.",
    category: "تحرير الصور",
    rating: 4.8,
    platform: "Android & iOS",
    downloadLink: "https://app.pixverse.ai/onboard",
    icon: "/images/apps/pixverse.png",
    screenshots: ["/images/blog/apps-collection.jpg", "/images/blog/apps-collection.jpg"],
    features: [
      "مجموعة متنوعة من الفلاتر والتأثيرات",
      "أدوات متقدمة لتعديل الألوان والإضاءة",
      "إمكانية إضافة نصوص وملصقات للصور",
      "قوالب جاهزة للاستخدام في السوشيال ميديا",
      "واجهة سهلة الاستخدام ومناسبة للمبتدئين والمحترفين",
    ],
    article: `
      <h2>تطبيق Pixverse: ثورة في عالم تحرير الصور</h2>
      
      <p>في عصر السوشيال ميديا والمحتوى البصري، أصبح تحرير الصور جزءًا أساسيًا من حياتنا اليومية. سواء كنت مصورًا محترفًا أو مجرد شخص يحب مشاركة لحظاته على منصات التواصل الاجتماعي، فإن الحصول على صور جذابة ومميزة أمر ضروري للتميز وجذب الانتباه.</p>
      
      <p>يأتي تطبيق Pixverse كحل متكامل لجميع احتياجات تحرير الصور، حيث يجمع بين سهولة الاستخدام والأدوات الاحترافية في واجهة بسيطة وأنيقة. دعونا نستكشف معًا ما يجعل هذا التطبيق خيارًا مثاليًا لتحرير صورك.</p>
      
      <h3>مميزات تطبيق Pixverse</h3>
      
      <p><strong>1. مجموعة واسعة من الفلاتر والتأثيرات:</strong> يوفر التطبيق مجموعة متنوعة من الفلاتر الجاهزة التي يمكنك تطبيقها بنقرة واحدة لتغيير مظهر صورك بالكامل. من الفلاتر الكلاسيكية إلى التأثيرات العصرية، هناك خيار مناسب لكل مناسبة ونمط.</p>
      
      <p><strong>2. أدوات تعديل متقدمة:</strong> لا يقتصر Pixverse على الفلاتر فقط، بل يوفر أدوات متقدمة لتعديل الصور مثل ضبط الإضاءة والتباين والتشبع والحدة وتوازن الألوان. يمكنك التحكم بدقة في كل جانب من جوانب صورتك للحصول على النتيجة المثالية.</p>
      
      <p><strong>3. أدوات إبداعية:</strong> يتميز التطبيق بمجموعة من الأدوات الإبداعية مثل إضافة النصوص والملصقات والرسومات. يمكنك إنشاء تصاميم فريدة وإضافة لمستك الشخصية إلى صورك.</p>
      
      <p><strong>4. تصحيح العيوب:</strong> يحتوي Pixverse على أدوات متخصصة لتصحيح عيوب البشرة وتحسين الصور الشخصية. يمكنك إزالة العيوب وتنعيم البشرة وتحسين ملامح الوجه بطريقة طبيعية.</p>
      
      <p><strong>5. قوالب جاهزة للسوشيال ميديا:</strong> يوفر التطبيق قوالب جاهزة بأحجام مناسبة لمختلف منصات التواصل الاجتماعي، مما يسهل عليك إنشاء محتوى مخصص لكل منصة.</p>
      
      <h3>كيفية استخدام تطبيق Pixverse</h3>
      
      <p>استخدام تطبيق Pixverse سهل للغاية حتى للمبتدئين. إليك الخطوات الأساسية:</p>
      
      <ol>
        <li>قم بتحميل التطبيق من متجر التطبيقات</li>
        <li>افتح التطبيق واختر صورة من معرض الصور أو التقط صورة جديدة</li>
        <li>استخدم أدوات التعديل الأساسية لضبط الإضاءة والألوان</li>
        <li>جرب الفلاتر المختلفة واختر ما يناسب صورتك</li>
        <li>أضف النصوص أو الملصقات إذا رغبت في ذلك</li>
        <li>احفظ الصورة أو شاركها مباشرة على منصات التواصل الاجتماعي</li>
      </ol>
      
      <h3>لماذا يجب عليك تجربة Pixverse؟</h3>
      
      <p>يتميز Pixverse عن غيره من تطبيقات تحرير الصور بالجمع بين البساطة والاحترافية. إنه مناسب للمبتدئين الذين يرغبون في تحسين صورهم بسرعة، وكذلك للمحترفين الذين يحتاجون إلى أدوات متقدمة للتعديل.</p>
      
      <p>بالإضافة إلى ذلك، يتم تحديث التطبيق باستمرار بفلاتر وميزات جديدة، مما يضمن لك البقاء في المقدمة دائمًا عندما يتعلق الأمر بتحرير الصور.</p>
      
      <h3>الخلاصة</h3>
      
      <p>إذا كنت تبحث عن تطبيق شامل لتحرير الصور يجمع بين سهولة الاستخدام والأدوات الاحترافية، فإن Pixverse هو الخيار المثالي لك. جربه اليوم واكتشف كيف يمكنه تحويل صورك العادية إلى أعمال فنية مذهلة.</p>
    `,
  },
  {
    id: "2",
    title: "ChatGPT",
    description:
      "تطبيق الذكاء الاصطناعي الشهير الذي يمكنك من التحدث مع مساعد ذكي والحصول على إجابات لأسئلتك ومساعدة في مختلف المهام. يمكنه كتابة النصوص، وحل المشكلات، وتقديم الاقتراحات.",
    category: "الذكاء الاصطناعي",
    rating: 4.7,
    platform: "Android & iOS",
    downloadLink: "https://play.google.com/store/apps/details?id=com.openai.chatgpt",
    icon: "/images/apps/chatgpt.png",
    screenshots: ["/images/blog/apps-collection.jpg", "/images/blog/apps-collection.jpg"],
    features: [
      "الإجابة على الأسئلة بدقة وشمولية",
      "كتابة وتحرير النصوص المختلفة",
      "مساعدة في البرمجة وحل المشكلات التقنية",
      "تقديم اقتراحات وأفكار إبداعية",
      "دعم للغة العربية والعديد من اللغات الأخرى",
    ],
    article: `
      <h2>تطبيق ChatGPT: ثورة الذكاء الاصطناعي في متناول يديك</h2>
      
      <p>في عصر التكنولوجيا المتسارع، أصبح الذكاء الاصطناعي جزءًا لا يتجزأ من حياتنا اليومية. ومن بين التطورات الأكثر إثارة في هذا المجال يأتي تطبيق ChatGPT، الذي يضع قوة الذكاء الاصطناعي التوليدي في متناول الجميع.</p>
      
      <p>تطبيق ChatGPT هو النسخة المحمولة من نموذج الذكاء الاصطناعي الشهير من OpenAI، والذي يتيح للمستخدمين التفاعل مع نظام ذكاء اصطناعي متطور قادر على فهم اللغة الطبيعية والرد بطريقة تشبه البشر.</p>
      
      <h3>مميزات تطبيق ChatGPT</h3>
      
      <p><strong>1. محادثات طبيعية:</strong> يمكنك التحدث مع ChatGPT كما لو كنت تتحدث مع شخص حقيقي. النظام قادر على فهم سياق المحادثة والاستمرار في الحوار بشكل طبيعي.</p>
      
      <p><strong>2. مساعدة متعددة المجالات:</strong> سواء كنت بحاجة إلى مساعدة في الكتابة، أو البحث عن معلومات، أو حل مشكلات برمجية، أو الحصول على أفكار إبداعية، فإن ChatGPT يمكنه تقديم المساعدة في مجموعة واسعة من المجالات.</p>
      
      <p><strong>3. دعم متعدد اللغات:</strong> يدعم التطبيق العديد من اللغات بما في ذلك العربية، مما يجعله أداة عالمية يمكن للجميع الاستفادة منها بغض النظر عن لغتهم الأم.</p>
      
      <p><strong>4. تحديثات مستمرة:</strong> يتم تحديث نماذج ChatGPT باستمرار، مما يعني أن التطبيق يتحسن باستمرار ويكتسب قدرات جديدة مع مرور الوقت.</p>
      
      <p><strong>5. واجهة بسيطة وسهلة الاستخدام:</strong> تم تصميم التطبيق ليكون سهل الاستخدام، مع واجهة بسيطة تشبه تطبيقات المراسلة التقليدية.</p>
      
      <h3>استخدامات تطبيق ChatGPT</h3>
      
      <p>يمكن استخدام ChatGPT في مجموعة متنوعة من السيناريوهات:</p>
      
      <ul>
        <li><strong>الكتابة والتحرير:</strong> مساعدة في كتابة المقالات، الرسائل، السير الذاتية، وتحرير النصوص.</li>
        <li><strong>التعلم:</strong> شرح المفاهيم المعقدة، المساعدة في حل الواجبات، وتقديم موارد تعليمية.</li>
        <li><strong>البرمجة:</strong> كتابة وتصحيح الكود، شرح المفاهيم البرمجية، واقتراح حلول للمشكلات التقنية.</li>
        <li><strong>الإبداع:</strong> توليد أفكار للمحتوى، كتابة القصص والشعر، واقتراح حلول إبداعية للمشكلات.</li>
        <li><strong>البحث:</strong> الحصول على معلومات حول مجموعة واسعة من المواضيع (مع ملاحظة أن معرفة النموذج قد تكون محدودة بتاريخ تدريبه).</li>
      </ul>
      
      <h3>كيفية استخدام تطبيق ChatGPT</h3>
      
      <p>استخدام تطبيق ChatGPT بسيط للغاية:</p>
      
      <ol>
        <li>قم بتحميل التطبيق من متجر التطبيقات</li>
        <li>قم بإنشاء حساب أو تسجيل الدخول إذا كان لديك حساب بالفعل</li>
        <li>ابدأ محادثة جديدة بالنقر على زر "محادثة جديدة"</li>
        <li>اكتب سؤالك أو طلبك في مربع النص</li>
        <li>انتظر الرد واستمر في المحادثة حسب الحاجة</li>
      </ol>
      
      <h3>نصائح لاستخدام أفضل لتطبيق ChatGPT</h3>
      
      <ul>
        <li><strong>كن محددًا:</strong> كلما كان سؤالك أو طلبك أكثر تحديدًا، كلما كان الرد أكثر فائدة.</li>
        <li><strong>استخدم المحادثات المستمرة:</strong> لا تتردد في طلب توضيحات أو طرح أسئلة متابعة. ChatGPT يتذكر سياق المحادثة.</li>
        <li><strong>تحقق من المعلومات:</strong> على الرغم من أن ChatGPT يحاول تقديم معلومات دقيقة، إلا أنه قد يخطئ أحيانًا. تحقق دائمًا من المعلومات المهمة من مصادر موثوقة.</li>
        <li><strong>استكشف الإعدادات:</strong> يوفر التطبيق إعدادات مختلفة يمكنك تخصيصها لتحسين تجربتك.</li>
      </ul>
      
      <h3>الخلاصة</h3>
      
      <p>تطبيق ChatGPT يمثل خطوة كبيرة في جعل تقنيات الذكاء الاصطناعي المتقدمة في متناول الجميع. سواء كنت طالبًا، أو محترفًا، أو مبدعًا، أو مجرد شخص فضولي، فإن هذا التطبيق يقدم قيمة هائلة ويفتح آفاقًا جديدة للتفاعل مع التكنولوجيا.</p>
      
      <p>مع استمرار تطور نماذج الذكاء الاصطناعي، من المثير أن نرى كيف سيستمر ChatGPT في التحسن وتوسيع قدراته في المستقبل.</p>
    `,
  },
  {
    id: "3",
    title: "CapCut",
    description:
      "تطبيق احترافي لتحرير الفيديوهات مع العديد من الأدوات والمؤثرات. مثالي لإنشاء محتوى فيديو احترافي للسوشيال ميديا. يوفر قوالب جاهزة وتأثيرات متنوعة لتحسين مقاطع الفيديو الخاصة بك.",
    category: "تحرير الفيديو",
    rating: 4.9,
    platform: "Android & iOS",
    downloadLink: "https://play.google.com/store/apps/details?id=com.lemon.lvoverseas",
    icon: "/images/apps/capcut.png",
    screenshots: ["/images/blog/apps-collection.jpg", "/images/blog/apps-collection.jpg"],
    features: [
      "قوالب جاهزة للاستخدام في السوشيال ميديا",
      "تأثيرات بصرية وانتقالات احترافية",
      "أدوات متقدمة لتعديل الصوت",
      "مكتبة موسيقى مجانية",
      "دعم لتصدير الفيديو بجودة عالية",
    ],
    article: `
      <h2>تطبيق CapCut: أداة احترافية لتحرير الفيديو في متناول الجميع</h2>
      
      <p>في عصر المحتوى المرئي، أصبح إنشاء مقاطع فيديو جذابة واحترافية أمرًا ضروريًا للتميز على منصات التواصل الاجتماعي. يأتي تطبيق CapCut كحل متكامل لتحرير الفيديو، يجمع بين الأدوات الاحترافية وسهولة الاستخدام، مما يجعله مناسبًا للمبتدئين والمحترفين على حد سواء.</p>
      
      <h3>مميزات تطبيق CapCut</h3>
      
      <p><strong>1. واجهة سهلة الاستخدام:</strong> على الرغم من قدراته المتقدمة، يتميز CapCut بواجهة بسيطة وبديهية تسهل على المستخدمين من جميع المستويات إنشاء مقاطع فيديو مذهلة.</p>
      
      <p><strong>2. قوالب جاهزة:</strong> يوفر التطبيق مجموعة واسعة من القوالب الجاهزة المصممة خصيصًا لمختلف منصات التواصل الاجتماعي مثل TikTok وInstagram وYouTube. هذه القوالب تسهل إنشاء محتوى احترافي بسرعة.</p>
      
      <p><strong>3. تأثيرات وانتقالات متنوعة:</strong> يحتوي CapCut على مكتبة ضخمة من التأثيرات البصرية والانتقالات التي يمكنك استخدامها لإضافة لمسة احترافية إلى مقاطع الفيديو الخاصة بك.</p>
      
      <p><strong>4. أدوات تعديل متقدمة:</strong> يوفر التطبيق أدوات متقدمة لتعديل الفيديو مثل تقسيم المقاطع، والقص، والدمج، وتغيير السرعة، وتعديل الألوان، وتثبيت الفيديو، وغيرها الكثير.</p>
      
      <p><strong>5. تعديل الصوت:</strong> يتضمن CapCut أدوات قوية لتعديل الصوت، بما في ذلك إزالة الضوضاء، وتعديل مستويات الصوت، وإضافة تأثيرات صوتية، ودمج مسارات صوتية متعددة.</p>
      
      <p><strong>6. مكتبة موسيقى مجانية:</strong> يوفر التطبيق مكتبة ضخمة من الموسيقى والمؤثرات الصوتية المجانية التي يمكنك استخدامها في مقاطع الفيديو الخاصة بك دون القلق بشأن حقوق الملكية.</p>
      
      <p><strong>7. دعم الطبقات المتعددة:</strong> يمكنك إضافة طبقات متعددة من النصوص والصور والفيديوهات، مما يتيح لك إنشاء محتوى غني ومتعدد الأبعاد.</p>
      
      <h3>كيفية استخدام تطبيق CapCut</h3>
      
      <p>استخدام تطبيق CapCut سهل نسبيًا، حتى للمبتدئين. إليك الخطوات الأساسية:</p>
      
      <ol>
        <li>قم بتحميل التطبيق من متجر التطبيقات</li>
        <li>افتح التطبيق وانقر على "مشروع جديد"</li>
        <li>اختر مقاطع الفيديو والصور التي ترغب في استخدامها</li>
        <li>استخدم أدوات التعديل لقص المقاطع وترتيبها</li>
        <li>أضف الانتقالات والتأثيرات حسب الرغبة</li>
        <li>أضف الموسيقى والمؤثرات الصوتية</li>
        <li>أضف النصوص والملصقات إذا رغبت في ذلك</li>
        <li>قم بتصدير الفيديو بالجودة المطلوبة</li>
      </ol>
      
      <h3>نصائح لاستخدام أفضل لتطبيق CapCut</h3>
      
      <ul>
        <li><strong>استكشف القوالب:</strong> استفد من القوالب الجاهزة لتوفير الوقت وإنشاء محتوى احترافي بسرعة.</li>
        <li><strong>تعلم الاختصارات:</strong> تعرف على اختصارات التطبيق لتسريع عملية التحرير.</li>
        <li><strong>استخدم الطبقات بذكاء:</strong> استفد من ميزة الطبقات المتعددة لإنشاء تأثيرات معقدة.</li>
        <li><strong>اهتم بالصوت:</strong> الصوت هو جزء أساسي من تجربة الفيديو، لذا اهتم بتعديله وتحسينه.</li>
        <li><strong>احفظ مشاريعك بانتظام:</strong> احرص على حفظ مشروعك بانتظام لتجنب فقدان عملك.</li>
      </ul>
      
      <h3>مقارنة مع تطبيقات تحرير الفيديو الأخرى</h3>
      
      <p>يتميز CapCut عن منافسيه بالجمع بين القدرات الاحترافية وسهولة الاستخدام، بالإضافة إلى كونه مجانيًا بالكامل مع عدم وجود علامات مائية على الفيديوهات المصدرة. في حين أن بعض التطبيقات الأخرى قد توفر ميزات متقدمة معينة، إلا أن CapCut يقدم حزمة متكاملة تلبي احتياجات معظم المستخدمين.</p>
      
      <h3>الخلاصة</h3>
      
      <p>تطبيق CapCut هو أداة قوية ومتعددة الاستخدامات لتحرير الفيديو، تناسب المبتدئين والمحترفين على حد سواء. مع مجموعة واسعة من الميزات والأدوات، يمكنك إنشاء محتوى فيديو احترافي لمختلف منصات التواصل الاجتماعي بسهولة وسرعة.</p>
      
      <p>سواء كنت منشئ محتوى طموحًا أو مجرد شخص يرغب في تحسين مقاطع الفيديو الشخصية، فإن CapCut يوفر لك كل ما تحتاجه لتحقيق رؤيتك الإبداعية.</p>
    `,
  },
]

export async function generateMetadata({ params }: { params: { id: string } }) {
  const app = appsData.find((app) => app.id === params.id)

  if (!app) {
    return {
      title: `تطبيق غير موجود | Pasha_jord`,
      description: "عذراً، التطبيق المطلوب غير موجود",
    }
  }

  return {
    title: `${app.title} | Pasha_jord`,
    description: app.description,
  }
}

export default function AppDetailPage({ params }: { params: { id: string } }) {
  const app = appsData.find((app) => app.id === params.id)

  if (!app) {
    return (
      <div className="min-h-screen flex flex-col tech-pattern">
        <Navbar />
        <main className="flex-1 container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">عذراً، التطبيق المطلوب غير موجود</h1>
            <p className="text-lg text-muted-foreground mb-8">لم نتمكن من العثور على التطبيق الذي تبحث عنه</p>
            <Link href="/apps">
              <Button>
                العودة إلى صفحة التطبيقات
                <ChevronRight className="mr-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="flex flex-wrap gap-2 items-center text-sm text-muted-foreground mb-4">
                <Link href="/apps" className="hover:text-primary">
                  التطبيقات
                </Link>
                <ChevronRight className="h-4 w-4" />
                <span>{app.category}</span>
                <ChevronRight className="h-4 w-4" />
                <span className="truncate max-w-[200px]">{app.title}</span>
              </div>
              <div className="flex items-center gap-6">
                <div className="relative h-24 w-24 rounded-xl bg-primary/10 flex items-center justify-center overflow-hidden">
                  <Image
                    src={app.icon || "/placeholder.svg"}
                    alt={app.title}
                    width={80}
                    height={80}
                    className="rounded-md"
                  />
                </div>
                <div>
                  <h1 className="text-4xl font-bold mb-2">{app.title}</h1>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 mr-1" />
                      <span className="font-medium">{app.rating.toFixed(1)}</span>
                    </div>
                    <span className="text-sm bg-muted px-2 py-1 rounded-full">{app.platform}</span>
                    <span className="text-sm text-muted-foreground">{app.category}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <Card className="p-6 mb-8">
              <h2 className="text-2xl font-bold mb-4">وصف التطبيق</h2>
              <p className="mb-6">{app.description}</p>

              <h3 className="text-xl font-bold mb-3">المميزات الرئيسية:</h3>
              <ul className="list-disc list-inside space-y-2 mr-4 mb-6">
                {app.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>

              <div className="mt-6">
                <CountdownButton href={app.downloadLink} initialSeconds={15}>
                  تحميل التطبيق
                </CountdownButton>
                <p className="text-center text-sm text-muted-foreground mt-2">سيتم تفعيل الرابط بعد 15 ثانية</p>
              </div>
            </Card>

            <AdBanner />

            <div className="mt-8">
              <h2 className="text-2xl font-bold mb-6">مقال عن التطبيق</h2>
              <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
                <Image src={app.icon || "/placeholder.svg"} alt={app.title} fill className="object-contain" />
              </div>
              <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                {app.screenshots.map((screenshot, index) => (
                  <div key={index} className="rounded-lg overflow-hidden">
                    <Image
                      src={screenshot || "/placeholder.svg"}
                      alt={`${app.title} Screenshot ${index + 1}`}
                      width={600}
                      height={300}
                      className="w-full h-auto object-cover"
                    />
                  </div>
                ))}
              </div>
              <div
                className="prose prose-lg dark:prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: app.article }}
              />
            </div>

            <AdBanner />

            <div className="mt-12 pt-8 border-t">
              <h3 className="text-2xl font-bold mb-6">تطبيقات ذات صلة</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {appsData
                  .filter((relatedApp) => relatedApp.id !== app.id)
                  .slice(0, 3)
                  .map((relatedApp) => (
                    <Link key={relatedApp.id} href={`/apps/${relatedApp.id}`} className="block">
                      <div className="bg-card rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                        <div className="p-4">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="relative h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
                              <Image
                                src={relatedApp.icon || "/placeholder.svg"}
                                alt={relatedApp.title}
                                width={40}
                                height={40}
                                className="rounded-md"
                              />
                            </div>
                            <div>
                              <h4 className="font-bold">{relatedApp.title}</h4>
                              <p className="text-xs text-muted-foreground">{relatedApp.category}</p>
                            </div>
                          </div>
                          <p className="text-sm line-clamp-2">{relatedApp.description}</p>
                          <div className="flex justify-between items-center mt-3">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                              <span className="text-sm">{relatedApp.rating.toFixed(1)}</span>
                            </div>
                            <Button variant="ghost" size="sm">
                              التفاصيل
                              <ChevronRight className="mr-1 h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
