import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, ChevronRight, Star, Filter } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "التطبيقات | Pasha_jord",
  description: "استكشف أحدث التطبيقات وأكثرها فائدة مع شروحات مفصلة",
}

export default function AppsPage() {
  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl font-bold">أحدث التطبيقات</h1>
              <p className="text-xl text-muted-foreground">
                استكشف مجموعة متنوعة من التطبيقات المفيدة مع شروحات مفصلة لكيفية استخدامها
              </p>
              <div className="relative max-w-md mx-auto mt-8">
                <Search className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input type="search" placeholder="ابحث عن تطبيق..." className="pr-10 py-6" />
              </div>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Filters */}
        <section className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              <h2 className="font-medium">تصفية النتائج:</h2>
            </div>
            <div className="flex flex-wrap gap-4">
              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="التصنيف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع التصنيفات</SelectItem>
                  <SelectItem value="photo">تحرير الصور</SelectItem>
                  <SelectItem value="video">تحرير الفيديو</SelectItem>
                  <SelectItem value="ai">الذكاء الاصطناعي</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="النظام" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنظمة</SelectItem>
                  <SelectItem value="android">Android</SelectItem>
                  <SelectItem value="ios">iOS</SelectItem>
                  <SelectItem value="both">كلاهما</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="الترتيب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">الأحدث</SelectItem>
                  <SelectItem value="popular">الأكثر شعبية</SelectItem>
                  <SelectItem value="rating">التقييم</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* Apps Grid */}
        <section className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <AppCard
              id={1}
              title="Pixverse"
              description="تطبيق رائع لتحرير الصور وإضافة تأثيرات مميزة. يمكنك استخدامه لإنشاء صور احترافية بسهولة وسرعة. يحتوي على العديد من الفلاتر والأدوات المتقدمة التي تساعدك في تحسين صورك."
              category="تحرير الصور"
              rating={4.8}
              platform="Android & iOS"
              downloadLink="https://app.pixverse.ai/onboard"
              imageSrc="/images/apps/pixverse.png"
            />
            <AppCard
              id={2}
              title="ChatGPT"
              description="تطبيق الذكاء الاصطناعي الشهير الذي يمكنك من التحدث مع مساعد ذكي والحصول على إجابات لأسئلتك ومساعدة في مختلف المهام. يمكنه كتابة النصوص، وحل المشكلات، وتقديم الاقتراحات."
              category="الذكاء الاصطناعي"
              rating={4.7}
              platform="Android & iOS"
              downloadLink="https://play.google.com/store/apps/details?id=com.openai.chatgpt"
              imageSrc="/images/apps/chatgpt.png"
            />
            <AppCard
              id={3}
              title="CapCut"
              description="تطبيق احترافي لتحرير الفيديوهات مع العديد من الأدوات والمؤثرات. مثالي لإنشاء محتوى فيديو احترافي للسوشيال ميديا. يوفر قوالب جاهزة وتأثيرات متنوعة لتحسين مقاطع الفيديو الخاصة بك."
              category="تحرير الفيديو"
              rating={4.9}
              platform="Android & iOS"
              downloadLink="https://play.google.com/store/apps/details?id=com.lemon.lvoverseas"
              imageSrc="/images/apps/capcut.png"
            />
          </div>
        </section>

        <AdBanner />

        {/* App Details */}
        <section className="container mx-auto px-4 py-12">
          <h2 className="text-3xl font-bold mb-8">تفاصيل التطبيقات</h2>

          <div className="space-y-12">
            <div className="bg-card rounded-lg p-6 shadow-sm">
              <h3 className="text-2xl font-bold mb-4">Pixverse</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    تطبيق Pixverse هو أداة متكاملة لتحرير الصور تتيح لك إنشاء صور مذهلة باستخدام مجموعة واسعة من الأدوات
                    والفلاتر. يمكنك استخدامه لتعديل الصور وإضافة تأثيرات خاصة وتحسين جودة الصور بشكل احترافي.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>مجموعة متنوعة من الفلاتر والتأثيرات</li>
                    <li>أدوات متقدمة لتعديل الألوان والإضاءة</li>
                    <li>إمكانية إضافة نصوص وملصقات للصور</li>
                    <li>قوالب جاهزة للاستخدام في السوشيال ميديا</li>
                    <li>واجهة سهلة الاستخدام ومناسبة للمبتدئين والمحترفين</li>
                  </ul>
                  <a href="https://app.pixverse.ai/onboard" target="_blank" rel="noopener noreferrer">
                    <Button>
                      تحميل التطبيق
                      <ChevronRight className="mr-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <Image
                      src="/images/apps/pixverse.png"
                      alt="Pixverse"
                      width={80}
                      height={80}
                      className="mx-auto mb-4 rounded-xl"
                    />
                    <div className="flex items-center justify-center mb-2">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 opacity-80" />
                    </div>
                    <p className="font-bold">4.8 / 5</p>
                    <p className="text-sm text-muted-foreground">متوفر على Android & iOS</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/blog/app-collection.png"
                    alt="Pixverse Screenshot 1"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/blog/social-media-apps.png"
                    alt="Pixverse Screenshot 2"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm">
              <h3 className="text-2xl font-bold mb-4">ChatGPT</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    تطبيق ChatGPT هو مساعد ذكاء اصطناعي متطور يمكنه الإجابة على أسئلتك ومساعدتك في مختلف المهام. يعتمد
                    على نماذج لغوية متقدمة تمكنه من فهم وإنتاج نصوص طبيعية تشبه ما يكتبه البشر.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>الإجابة على الأسئلة بدقة وشمولية</li>
                    <li>كتابة وتحرير النصوص المختلفة</li>
                    <li>مساعدة في البرمجة وحل المشكلات التقنية</li>
                    <li>تقديم اقتراحات وأفكار إبداعية</li>
                    <li>دعم للغة العربية والعديد من اللغات الأخرى</li>
                  </ul>
                  <a
                    href="https://play.google.com/store/apps/details?id=com.openai.chatgpt"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button>
                      تحميل التطبيق
                      <ChevronRight className="mr-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <Image
                      src="/images/apps/chatgpt.png"
                      alt="ChatGPT"
                      width={80}
                      height={80}
                      className="mx-auto mb-4 rounded-xl"
                    />
                    <div className="flex items-center justify-center mb-2">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 opacity-70" />
                    </div>
                    <p className="font-bold">4.7 / 5</p>
                    <p className="text-sm text-muted-foreground">متوفر على Android & iOS</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/blog/social-media-3d.png"
                    alt="ChatGPT Screenshot 1"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/blog/web-design-purple.png"
                    alt="ChatGPT Screenshot 2"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm">
              <h3 className="text-2xl font-bold mb-4">CapCut</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    تطبيق CapCut هو محرر فيديو احترافي يوفر مجموعة واسعة من الأدوات لإنشاء مقاطع فيديو مذهلة. يتميز
                    بواجهة سهلة الاستخدام وميزات متقدمة تناسب المبتدئين والمحترفين على حد سواء.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>قوالب جاهزة للاستخدام في السوشيال ميديا</li>
                    <li>تأثيرات بصرية وانتقالات احترافية</li>
                    <li>أدوات متقدمة لتعديل الصوت</li>
                    <li>مكتبة موسيقى مجانية</li>
                    <li>دعم لتصدير الفيديو بجودة عالية</li>
                  </ul>
                  <a
                    href="https://play.google.com/store/apps/details?id=com.lemon.lvoverseas"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button>
                      تحميل التطبيق
                      <ChevronRight className="mr-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <Image
                      src="/images/apps/capcut.png"
                      alt="CapCut"
                      width={80}
                      height={80}
                      className="mx-auto mb-4 rounded-xl"
                    />
                    <div className="flex items-center justify-center mb-2">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 opacity-90" />
                    </div>
                    <p className="font-bold">4.9 / 5</p>
                    <p className="text-sm text-muted-foreground">متوفر على Android & iOS</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/blog/web-design-interactive.png"
                    alt="CapCut Screenshot 1"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="rounded-lg overflow-hidden">
                  <Image
                    src="/images/blog/web-development.png"
                    alt="CapCut Screenshot 2"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <AdBanner />
      </main>

      <Footer />
    </div>
  )
}

// Update the AppCard function to use the correct images
function AppCard({
  id,
  title,
  description,
  category,
  rating,
  platform,
  downloadLink,
  imageSrc,
}: {
  id: number
  title: string
  description: string
  category: string
  rating: number
  platform: string
  downloadLink: string
  imageSrc: string
}) {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex gap-4 items-center">
            <div className="relative h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
              <Image
                src={imageSrc || "/placeholder.svg"}
                alt={title}
                width={48}
                height={48}
                className="object-contain"
              />
            </div>
            <div>
              <CardTitle>{title}</CardTitle>
              <CardDescription>{category}</CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="line-clamp-3">{description}</p>

        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
            <span className="text-sm font-medium">{rating.toFixed(1)}</span>
          </div>
          <span className="text-xs bg-muted px-2 py-1 rounded-full">{platform}</span>
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/apps/${id}`} className="w-full">
          <Button className="w-full">
            التفاصيل
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
