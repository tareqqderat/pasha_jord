import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Script from "next/script"
import { SoundProvider } from "@/components/sound-effect"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
})

export const metadata: Metadata = {
  title: "Pasha_jord | موقع التطبيقات والمواقع والذكاء الاصطناعي",
  description: "موقع متخصص في شرح أحدث التطبيقات والمواقع وتقنيات الذكاء الاصطناعي",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        {/* Google AdSense Script */}
        <Script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8519995695583490"
          crossOrigin="anonymous"
        />
        <Script id="adsense-init">
          {`
            (adsbygoogle = window.adsbygoogle || []).push({
              google_ad_client: "ca-pub-8519995695583490", 
              enable_page_level_ads: true 
            });
          `}
        </Script>

        {/* Google Analytics (Google tag) */}
        <Script async src="https://www.googletagmanager.com/gtag/js?id=G-T889RRXC30" strategy="afterInteractive" />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-T889RRXC30');
          `}
        </Script>

        {/* Adsterra Ads Script */}
        <Script id="adsterra-ads" strategy="afterInteractive">
          {`
            (function() {
              var script = document.createElement('script');
              script.type = 'text/javascript';
              script.src = '//pl26610299.profitableratecpm.com/65/de/cc/65decc034c5cee36399b66c4ce20a343.js';
              document.head.appendChild(script);
            })();
          `}
        </Script>

        {/* Pomegranate Ads Script 1 */}
        <Script id="pomegranate-ads-1" strategy="afterInteractive">
          {`
            (function() {
              var script = document.createElement('script');
              script.type = 'text/javascript';
              script.src = '//pomegranatestaff.com/e0/21/91/e0219184cac6da69427612c0765fd8d8.js';
              document.head.appendChild(script);
            })();
          `}
        </Script>
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <SoundProvider>{children}</SoundProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
