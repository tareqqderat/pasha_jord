import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Sparkles, ChevronRight, Filter } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"

export const metadata = {
  title: "الذكاء الاصطناعي | Pasha_jord",
  description: "استكشف أحدث أدوات الذكاء الاصطناعي مع شروحات مفصلة",
}

export default function AIPage() {
  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl font-bold">أدوات الذكاء الاصطناعي</h1>
              <p className="text-xl text-muted-foreground">
                استكشف أحدث أدوات الذكاء الاصطناعي مع شروحات مفصلة لكيفية استخدامها
              </p>
              <div className="relative max-w-md mx-auto mt-8">
                <Search className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input type="search" placeholder="ابحث عن أداة ذكاء اصطناعي..." className="pr-10 py-6" />
              </div>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Filters */}
        <section className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              <h2 className="font-medium">تصفية النتائج:</h2>
            </div>
            <div className="flex flex-wrap gap-4">
              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="النوع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنواع</SelectItem>
                  <SelectItem value="text">معالجة النصوص</SelectItem>
                  <SelectItem value="image">توليد الصور</SelectItem>
                  <SelectItem value="audio">معالجة الصوت</SelectItem>
                  <SelectItem value="video">معالجة الفيديو</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="السعر" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأسعار</SelectItem>
                  <SelectItem value="free">مجاني</SelectItem>
                  <SelectItem value="freemium">مجاني مع ميزات مدفوعة</SelectItem>
                  <SelectItem value="paid">مدفوع</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="الترتيب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">الأحدث</SelectItem>
                  <SelectItem value="popular">الأكثر شعبية</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* AI Tools Grid */}
        <section className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 12 }).map((_, index) => (
              <AICard
                key={index}
                id={index + 1}
                title={`أداة ذكاء اصطناعي ${index + 1}`}
                description="وصف مختصر لأداة الذكاء الاصطناعي وكيفية الاستفادة منها. يمكنك استخدام هذه الأداة لتحسين إنتاجيتك وتوفير الوقت."
                category={
                  index % 4 === 0
                    ? "معالجة النصوص"
                    : index % 4 === 1
                      ? "توليد الصور"
                      : index % 4 === 2
                        ? "معالجة الصوت"
                        : "معالجة الفيديو"
                }
                isNew={index % 5 === 0}
                price={index % 3 === 0 ? "مجاني" : index % 3 === 1 ? "مجاني مع ميزات مدفوعة" : "مدفوع"}
              />
            ))}
          </div>

          <div className="flex justify-center mt-12">
            <Button variant="outline" size="lg">
              تحميل المزيد
            </Button>
          </div>
        </section>

        <AdBanner />
      </main>

      <Footer />
    </div>
  )
}

function AICard({
  id,
  title,
  description,
  category,
  isNew,
  price,
}: {
  id: number
  title: string
  description: string
  category: string
  isNew: boolean
  price: string
}) {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex gap-4 items-center">
            <div className="relative h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <div>
              <CardTitle>{title}</CardTitle>
              <CardDescription>{category}</CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="line-clamp-3">{description}</p>

        <div className="flex justify-between items-center">
          {isNew && <div className="bg-green-500 text-white text-xs font-medium px-2 py-1 rounded">جديد</div>}
          {!isNew && <div></div>}
          <span className="text-xs bg-muted px-2 py-1 rounded-full">{price}</span>
        </div>
      </CardContent>
      <CardFooter>
        <Button variant="outline" className="w-full">
          استكشاف الأداة
          <ChevronRight className="mr-2 h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  )
}
