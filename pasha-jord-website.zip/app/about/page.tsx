import { Button } from "@/components/ui/button"
import Image from "next/image"
import { Instagram, Youtube, Mail } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"

export const metadata = {
  title: "من نحن | Pasha_jord",
  description: "تعرف على Pasha_jord وفريق العمل والرؤية والرسالة",
}

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl font-bold">من نحن</h1>
              <p className="text-xl text-muted-foreground">تعرف على Pasha_jord وفريق العمل والرؤية والرسالة</p>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* About Us */}
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">قصتنا</h2>
              <p className="text-lg mb-4">
                بدأت رحلة Pasha_jord كمنصة لمشاركة المعرفة والخبرات في مجال التكنولوجيا والتطبيقات والمواقع المفيدة.
                هدفنا هو تقديم محتوى عربي مميز يساعد المستخدمين على الاستفادة القصوى من التكنولوجيا الحديثة وتطبيقاتها
                المختلفة.
              </p>
              <p className="text-lg mb-4">
                نسعى في Pasha_jord إلى تبسيط التكنولوجيا وجعلها في متناول الجميع من خلال تقديم شروحات مفصلة ونصائح عملية
                حول أحدث التطبيقات والمواقع وبوتات تلجرام وكيفية الاستفادة منها في حياتنا اليومية.
              </p>
              <p className="text-lg">
                فريقنا يتكون من مجموعة من الخبراء والمتحمسين للتكنولوجيا الذين يشاركون شغفهم ومعرفتهم مع المجتمع العربي،
                ويسعون دائماً لتقديم كل ما هو جديد ومفيد.
              </p>
            </div>
            <div className="relative h-80 rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=400&width=600&text=Pasha_jord"
                alt="Pasha_jord Team"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="bg-muted py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="bg-card p-8 rounded-lg shadow-sm">
                <h3 className="text-2xl font-bold mb-4">رؤيتنا</h3>
                <p className="text-lg">
                  نطمح أن نكون المرجع الأول للمستخدم العربي في مجال التكنولوجيا والتطبيقات والمواقع المفيدة، وأن نساهم
                  في نشر الوعي التكنولوجي وتعزيز المحتوى العربي الرقمي.
                </p>
              </div>
              <div className="bg-card p-8 rounded-lg shadow-sm">
                <h3 className="text-2xl font-bold mb-4">رسالتنا</h3>
                <p className="text-lg">
                  تقديم محتوى عربي مميز وموثوق يساعد المستخدمين على اكتشاف واستخدام أحدث التطبيقات والمواقع وبوتات
                  تلجرام بطريقة سهلة وفعالة، وتمكينهم من مواكبة التطور التكنولوجي المتسارع.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Us */}
        <section className="container mx-auto px-4 py-12">
          <h2 className="text-3xl font-bold text-center mb-12">تواصل معنا</h2>
          <div className="max-w-3xl mx-auto bg-card p-8 rounded-lg shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">معلومات التواصل</h3>
                <ul className="space-y-4">
                  <li className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-primary" />
                    <span>pasha.8rqt@gmail.com</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Instagram className="h-5 w-5 text-primary" />
                    <a
                      href="https://www.instagram.com/pasha_jord"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary"
                    >
                      @pasha_jord
                    </a>
                  </li>
                  <li className="flex items-center gap-2">
                    <Youtube className="h-5 w-5 text-primary" />
                    <a
                      href="https://youtube.com/@pasha_jord?si=wmEesdZh_5FkZmRl"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary"
                    >
                      Pasha_jord
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">أرسل لنا رسالة</h3>
                <form className="space-y-4">
                  <div>
                    <input
                      type="text"
                      placeholder="الاسم"
                      className="w-full px-4 py-2 rounded-md border focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <input
                      type="email"
                      placeholder="البريد الإلكتروني"
                      className="w-full px-4 py-2 rounded-md border focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <textarea
                      placeholder="الرسالة"
                      rows={4}
                      className="w-full px-4 py-2 rounded-md border focus:outline-none focus:ring-2 focus:ring-primary"
                    ></textarea>
                  </div>
                  <Button type="submit">إرسال الرسالة</Button>
                </form>
              </div>
            </div>
          </div>
        </section>

        <AdBanner />
      </main>

      <Footer />
    </div>
  )
}
