import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MessageCircle, ChevronRight, Filter, ExternalLink } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AdBanner from "@/components/ad-banner"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "بوتات تلجرام | Pasha_jord",
  description: "استكشف أفضل بوتات تلجرام مع شروحات مفصلة لكيفية استخدامها",
}

export default function TelegramBotsPage() {
  return (
    <div className="min-h-screen flex flex-col tech-pattern">
      <Navbar />

      <main className="flex-1">
        {/* Header */}
        <section className="bg-primary/10 py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center space-y-4">
              <h1 className="text-4xl font-bold">بوتات تلجرام</h1>
              <p className="text-xl text-muted-foreground">استكشف أفضل بوتات تلجرام مع شروحات مفصلة لكيفية استخدامها</p>
              <div className="relative max-w-md mx-auto mt-8">
                <Search className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input type="search" placeholder="ابحث عن بوت..." className="pr-10 py-6" />
              </div>
            </div>
          </div>
        </section>

        <AdBanner />

        {/* Filters */}
        <section className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              <h2 className="font-medium">تصفية النتائج:</h2>
            </div>
            <div className="flex flex-wrap gap-4">
              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="التصنيف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع التصنيفات</SelectItem>
                  <SelectItem value="photo">تصوير</SelectItem>
                  <SelectItem value="download">تحميل</SelectItem>
                  <SelectItem value="tools">أدوات</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="الترتيب" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">الأحدث</SelectItem>
                  <SelectItem value="popular">الأكثر شعبية</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* Telegram Bots Grid */}
        <section className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TelegramBotCard
              id={1}
              title="بوت تصوير الأشخاص"
              description="بوت تلجرام يساعدك في تصوير الأشخاص بطريقة مميزة. يمكنك استخدامه لإنشاء صور شخصية احترافية وتعديلها بسهولة."
              category="تصوير"
              isNew={true}
              botLink="https://t.me/Prankstdbot"
              icon={
                <Image
                  src="/placeholder.svg?height=50&width=50&text=TB"
                  alt="تصوير بوت"
                  width={40}
                  height={40}
                  className="rounded-md"
                />
              }
            />
            <TelegramBotCard
              id={2}
              title="بوت تحميل الفيديوهات"
              description="بوت تلجرام يساعدك في تحميل الفيديوهات من مختلف المنصات بسهولة وسرعة. مثالي لحفظ المحتوى المفضل لديك من يوتيوب وتيك توك وانستقرام وغيرها."
              category="تحميل"
              isNew={false}
              botLink="https://t.me/SocialMediaDownloader_Bot"
              icon={
                <Image
                  src="/placeholder.svg?height=50&width=50&text=DL"
                  alt="تحميل بوت"
                  width={40}
                  height={40}
                  className="rounded-md"
                />
              }
            />
            <TelegramBotCard
              id={3}
              title="Truecaller"
              description="بوت تلجرام يساعدك في معرفة هوية المتصل ومعلومات الأرقام. يمكنك استخدامه للبحث عن أرقام الهواتف ومعرفة أصحابها."
              category="أدوات"
              isNew={true}
              botLink="https://t.me/TrueCaller_Z_Bot"
              icon="/images/bots/telegram-icon.png"
            />
            <TelegramBotCard
              id={4}
              title="ElevenLabs"
              description="بوت تلجرام متخصص في تحويل النص إلى صوت بجودة عالية وبأصوات متعددة. مثالي لإنشاء تعليق صوتي احترافي."
              category="الذكاء الاصطناعي"
              isNew={true}
              botLink="https://t.me/elevenlabsiobot"
              icon="/images/bots/telegram-icon.png"
            />
            <TelegramBotCard
              id={5}
              title="CCL"
              description="بوت تلجرام متعدد الاستخدامات يوفر العديد من الأدوات المفيدة في مكان واحد. يساعدك في مختلف المهام اليومية."
              category="أدوات متنوعة"
              isNew={false}
              botLink="https://t.me/kinskbot"
              icon="/images/bots/telegram-icon.png"
            />
          </div>
        </section>

        <AdBanner />

        {/* Bot Details */}
        <section className="container mx-auto px-4 py-12">
          <h2 className="text-3xl font-bold mb-8">تفاصيل البوتات</h2>

          <div className="space-y-12">
            <div className="bg-card rounded-lg p-6 shadow-sm" id="bot-1">
              <h3 className="text-2xl font-bold mb-4">بوت تصوير الأشخاص</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    بوت تصوير الأشخاص هو بوت تلجرام متخصص في تحرير الصور الشخصية وإضافة تأثيرات مميزة عليها. يمكنك
                    استخدامه لإنشاء صور شخصية احترافية بسهولة وسرعة.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>تحرير الصور الشخصية بطرق احترافية</li>
                    <li>إضافة تأثيرات وفلاتر متنوعة</li>
                    <li>تغيير خلفية الصور بسهولة</li>
                    <li>إمكانية إضافة نصوص وملصقات</li>
                    <li>سرعة في المعالجة وجودة عالية للصور</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>افتح تطبيق تلجرام وابحث عن البوت @Prankstdbot</li>
                    <li>اضغط على زر "ابدأ" أو "Start"</li>
                    <li>أرسل الصورة التي ترغب بتعديلها</li>
                    <li>اختر التأثير أو التعديل المطلوب</li>
                    <li>انتظر حتى يتم معالجة الصورة وإرسالها إليك</li>
                  </ol>
                  <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg border border-yellow-200 dark:border-yellow-800 mb-4">
                    <p className="text-yellow-800 dark:text-yellow-200">
                      <strong>ملاحظة:</strong> يرجى استخدام هذا البوت بمسؤولية واحترام خصوصية الآخرين. لا تستخدم الصور
                      المعدلة لأغراض غير أخلاقية أو غير قانونية.
                    </p>
                  </div>
                  <a href="https://t.me/Prankstdbot" target="_blank" rel="noopener noreferrer">
                    <Button>
                      فتح البوت
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>

                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=300&width=600&text=Photo Bot Screenshot 1"
                        alt="Photo Bot Screenshot 1"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=300&width=600&text=Photo Bot Screenshot 2"
                        alt="Photo Bot Screenshot 2"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <MessageCircle className="h-16 w-16 text-primary mx-auto mb-4" />
                    <div className="bg-green-500 text-white text-xs font-medium px-2 py-1 rounded mb-4 inline-block">
                      جديد
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: تصوير</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm" id="bot-2">
              <h3 className="text-2xl font-bold mb-4">بوت تحميل الفيديوهات</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    بوت تحميل الفيديوهات هو بوت تلجرام يساعدك في تحميل الفيديوهات من مختلف المنصات مثل يوتيوب وتيك توك
                    وانستقرام وفيسبوك وتويتر وغيرها. يمكنك استخدامه لحفظ المحتوى المفضل لديك بسهولة وسرعة.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>تحميل الفيديوهات من مختلف المنصات</li>
                    <li>دعم لجودات مختلفة للفيديو</li>
                    <li>إمكانية تحميل الصوت فقط من الفيديوهات</li>
                    <li>سرعة في التحميل وجودة عالية</li>
                    <li>سهولة الاستخدام</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>افتح تطبيق تلجرام وابحث عن البوت @SaveVideoBot</li>
                    <li>اضغط على زر "ابدأ" أو "Start"</li>
                    <li>انسخ رابط الفيديو الذي ترغب بتحميله</li>
                    <li>أرسل الرابط إلى البوت</li>
                    <li>اختر جودة الفيديو المطلوبة</li>
                    <li>انتظر حتى يتم تحميل الفيديو وإرساله إليك</li>
                  </ol>
                  <a href="https://t.me/SocialMediaDownloader_Bot" target="_blank" rel="noopener noreferrer">
                    <Button>
                      فتح البوت
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>

                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=300&width=600&text=Video Downloader Bot Screenshot 1"
                        alt="Video Downloader Bot Screenshot 1"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=300&width=600&text=Video Downloader Bot Screenshot 2"
                        alt="Video Downloader Bot Screenshot 2"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <MessageCircle className="h-16 w-16 text-primary mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: تحميل</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm" id="bot-3">
              <h3 className="text-2xl font-bold mb-4">Truecaller</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    بوت Truecaller هو بوت تلجرام يساعدك في معرفة هوية المتصل ومعلومات الأرقام. يمكنك استخدامه للبحث عن
                    أرقام الهواتف ومعرفة أصحابها، مما يساعدك في تجنب المكالمات المزعجة والاحتيالية.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>البحث عن معلومات أرقام الهواتف</li>
                    <li>معرفة هوية المتصل</li>
                    <li>حظر المكالمات المزعجة</li>
                    <li>سهولة الاستخدام والسرعة في الاستجابة</li>
                    <li>دعم للعديد من الدول والمناطق</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>افتح تطبيق تلجرام وابحث عن البوت @TrueCaller_Z_Bot</li>
                    <li>اضغط على زر "ابدأ" أو "Start"</li>
                    <li>أرسل رقم الهاتف الذي ترغب في البحث عنه</li>
                    <li>انتظر حتى يقوم البوت بالبحث وإرسال المعلومات إليك</li>
                  </ol>
                  <a href="https://t.me/TrueCaller_Z_Bot" target="_blank" rel="noopener noreferrer">
                    <Button>
                      فتح البوت
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>

                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/images/bots/truecaller-screenshot-1.png"
                        alt="Truecaller Bot Screenshot 1"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/images/bots/truecaller-screenshot-2.png"
                        alt="Truecaller Bot Screenshot 2"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <MessageCircle className="h-16 w-16 text-primary mx-auto mb-4" />
                    <div className="bg-green-500 text-white text-xs font-medium px-2 py-1 rounded mb-4 inline-block">
                      جديد
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: أدوات</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm" id="bot-4">
              <h3 className="text-2xl font-bold mb-4">ElevenLabs</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    بوت ElevenLabs هو بوت تلجرام متخصص في تحويل النص إلى صوت بجودة عالية وبأصوات متعددة. يستخدم تقنيات
                    الذكاء الاصطناعي المتطورة لإنشاء تعليق صوتي يشبه الصوت البشري الطبيعي.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>تحويل النص إلى صوت بجودة عالية</li>
                    <li>دعم للعديد من اللغات بما فيها العربية</li>
                    <li>أصوات متعددة ومتنوعة</li>
                    <li>إمكانية التحكم في نبرة الصوت وسرعته</li>
                    <li>سهولة الاستخدام والسرعة في المعالجة</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>افتح تطبيق تلجرام وابحث عن البوت @elevenlabsiobot</li>
                    <li>اضغط على زر "ابدأ" أو "Start"</li>
                    <li>اختر اللغة والصوت المطلوب</li>
                    <li>أرسل النص الذي ترغب في تحويله إلى صوت</li>
                    <li>انتظر حتى يقوم البوت بمعالجة النص وإرسال الملف الصوتي إليك</li>
                  </ol>
                  <a href="https://t.me/elevenlabsiobot" target="_blank" rel="noopener noreferrer">
                    <Button>
                      فتح البوت
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>

                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/images/bots/elevenlabs-screenshot-1.png"
                        alt="ElevenLabs Bot Screenshot 1"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/images/bots/elevenlabs-screenshot-2.png"
                        alt="ElevenLabs Bot Screenshot 2"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <MessageCircle className="h-16 w-16 text-primary mx-auto mb-4" />
                    <div className="bg-green-500 text-white text-xs font-medium px-2 py-1 rounded mb-4 inline-block">
                      جديد
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: الذكاء الاصطناعي</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg p-6 shadow-sm" id="bot-5">
              <h3 className="text-2xl font-bold mb-4">CCL</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2">
                  <p className="mb-4">
                    بوت CCL هو بوت تلجرام متعدد الاستخدامات يوفر العديد من الأدوات المفيدة في مكان واحد. يمكنك استخدامه
                    للعديد من المهام اليومية مثل تحميل الفيديوهات، وتحرير الصور، وترجمة النصوص، وغيرها الكثير.
                  </p>
                  <h4 className="text-xl font-semibold mb-2">المميزات الرئيسية:</h4>
                  <ul className="list-disc list-inside space-y-2 mr-4 mb-4">
                    <li>تحميل الفيديوهات من مختلف المنصات</li>
                    <li>تحرير الصور وإضافة تأثيرات</li>
                    <li>ترجمة النصوص بين مختلف اللغات</li>
                    <li>البحث عن المعلومات والأخبار</li>
                    <li>العديد من الأدوات المفيدة الأخرى</li>
                  </ul>
                  <h4 className="text-xl font-semibold mb-2">كيفية الاستخدام:</h4>
                  <ol className="list-decimal list-inside space-y-2 mr-4 mb-4">
                    <li>افتح تطبيق تلجرام وابحث عن البوت @kinskbot</li>
                    <li>اضغط على زر "ابدأ" أو "Start"</li>
                    <li>اختر الأداة التي ترغب في استخدامها من القائمة</li>
                    <li>اتبع التعليمات الخاصة بكل أداة</li>
                  </ol>
                  <a href="https://t.me/kinskbot" target="_blank" rel="noopener noreferrer">
                    <Button>
                      فتح البوت
                      <ExternalLink className="mr-2 h-4 w-4" />
                    </Button>
                  </a>

                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/images/bots/ccl-screenshot-1.png"
                        alt="CCL Bot Screenshot 1"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                    <div className="rounded-lg overflow-hidden">
                      <Image
                        src="/images/bots/ccl-screenshot-2.png"
                        alt="CCL Bot Screenshot 2"
                        width={600}
                        height={300}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-muted rounded-lg flex items-center justify-center p-4">
                  <div className="text-center">
                    <MessageCircle className="h-16 w-16 text-primary mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground mt-2">التصنيف: أدوات متنوعة</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <AdBanner />
      </main>

      <Footer />
    </div>
  )
}

// Update the TelegramBotCard function to use the correct images
function TelegramBotCard({
  id,
  title,
  description,
  category,
  isNew,
  botLink,
  icon = <MessageCircle className="h-8 w-8 text-primary" />,
}: {
  id: number
  title: string
  description: string
  category: string
  isNew: boolean
  botLink: string
  icon?: React.ReactNode
}) {
  // Use the actual image path for the icon
  const iconSrc = typeof icon === "string" ? icon : "/images/bots/telegram-icon.png"

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex gap-4 items-center">
            <div className="relative h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
              {typeof icon === "string" ? (
                <Image
                  src={iconSrc || "/placeholder.svg"}
                  alt={title}
                  width={48}
                  height={48}
                  className="object-contain"
                />
              ) : (
                icon
              )}
            </div>
            <div>
              <CardTitle>{title}</CardTitle>
              <CardDescription>{category}</CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="line-clamp-3">{description}</p>

        <div className="flex justify-between items-center">
          {isNew && <div className="bg-green-500 text-white text-xs font-medium px-2 py-1 rounded">جديد</div>}
          {!isNew && <div></div>}
          <span className="text-xs bg-muted px-2 py-1 rounded-full">تلجرام</span>
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/telegram-bots/${id}`} className="w-full">
          <Button className="w-full">
            التفاصيل
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
