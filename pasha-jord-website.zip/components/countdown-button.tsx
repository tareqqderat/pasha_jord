"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"

export function CountdownButton({
  initialSeconds = 20,
  href,
  children,
  variant = "default",
}: {
  initialSeconds?: number
  href: string
  children: React.ReactNode
  variant?: "default" | "outline" | "secondary" | "destructive" | "ghost" | "link"
}) {
  const [seconds, setSeconds] = useState(initialSeconds)
  const [isActive, setIsActive] = useState(true)

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isActive && seconds > 0) {
      interval = setInterval(() => {
        setSeconds((prevSeconds) => prevSeconds - 1)
      }, 1000)
    } else if (seconds === 0) {
      setIsActive(false)
      if (interval) clearInterval(interval)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, seconds])

  return (
    <div className="w-full">
      {seconds > 0 ? (
        <div className="w-full">
          <div className="mb-3 bg-muted rounded-lg p-4 text-center">
            <p className="text-lg font-medium mb-2">يرجى الانتظار</p>
            <div className="flex items-center justify-center gap-2">
              <div className="text-3xl font-bold text-primary">{seconds}</div>
              <div className="text-sm text-muted-foreground">ثانية متبقية</div>
            </div>
            <div className="mt-2 w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
              <div
                className="bg-primary h-2.5 rounded-full transition-all duration-1000"
                style={{ width: `${(seconds / initialSeconds) * 100}%` }}
              ></div>
            </div>
          </div>
          <Button variant={variant} className="w-full opacity-70 cursor-not-allowed" disabled>
            انتظر {seconds} ثانية
          </Button>
        </div>
      ) : (
        <a href={href} target="_blank" rel="noopener noreferrer" className="w-full">
          <Button variant={variant} className="w-full">
            {children}
            <ExternalLink className="mr-2 h-4 w-4" />
          </Button>
        </a>
      )}
    </div>
  )
}
