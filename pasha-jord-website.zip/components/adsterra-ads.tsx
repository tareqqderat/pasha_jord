"use client"

import { useEffect } from "react"

export function AdsterraAds() {
  useEffect(() => {
    // Create script element
    const script = document.createElement("script")
    script.type = "text/javascript"
    script.src = "//pl26610299.profitableratecpm.com/65/de/cc/65decc034c5cee36399b66c4ce20a343.js"
    script.async = true

    // Append to document
    document.head.appendChild(script)

    return () => {
      // Cleanup if component unmounts
      try {
        document.head.removeChild(script)
      } catch (e) {
        console.error("Error removing Adsterra script:", e)
      }
    }
  }, [])

  return null
}
