import Link from "next/link"
import Image from "next/image"
import { Instagram, Youtube, Mail } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-muted py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="relative h-10 w-10 overflow-hidden rounded-full">
                <Image src="/logo.png" alt="Pasha_jord Logo" fill className="object-cover" />
              </div>
              <span className="font-bold text-xl">Pasha_jord</span>
            </div>
            <p className="text-muted-foreground">
              موقعك الأول لاستكشاف أحدث التطبيقات والمواقع وتقنيات الذكاء الاصطناعي
            </p>
            <div className="flex gap-4">
              <Link href="https://www.instagram.com/pasha_jord/" className="text-muted-foreground hover:text-primary">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link
                href="https://youtube.com/@pasha_jord?si=wmEesdZh_5FkZmRl"
                className="text-muted-foreground hover:text-primary"
              >
                <Youtube className="h-5 w-5" />
                <span className="sr-only">Youtube</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-primary">
                  الرئيسية
                </Link>
              </li>
              <li>
                <Link href="/apps" className="text-muted-foreground hover:text-primary">
                  تطبيقات
                </Link>
              </li>
              <li>
                <Link href="/websites" className="text-muted-foreground hover:text-primary">
                  مواقع
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary">
                  المدونة
                </Link>
              </li>
              <li>
                <Link href="/telegram-bots" className="text-muted-foreground hover:text-primary">
                  بوتات تلجرام
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary">
                  من نحن
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">الأقسام</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/apps" className="text-muted-foreground hover:text-primary">
                  تطبيقات الإنتاجية
                </Link>
              </li>
              <li>
                <Link href="/websites" className="text-muted-foreground hover:text-primary">
                  مواقع تعليمية
                </Link>
              </li>
              <li>
                <Link href="/ai" className="text-muted-foreground hover:text-primary">
                  أدوات الذكاء الاصطناعي
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary">
                  وسائل التواصل الاجتماعي
                </Link>
              </li>
              <li>
                <Link href="/telegram-bots" className="text-muted-foreground hover:text-primary">
                  تصميم وإبداع
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">تواصل معنا</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                <span className="text-muted-foreground">pasha.8rqt@gmail.com</span>
              </li>
              <div></div>
            </ul>
          </div>
        </div>

        <div className="border-t mt-12 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Pasha_jord. تم إنشاؤه بواسطة{" "}
            <a
              href="https://www.instagram.com/8rq_t/"
              className="hover:text-primary"
              target="_blank"
              rel="noopener noreferrer"
            >
              @8rq_t
            </a>
            . جميع الحقوق محفوظة.
          </p>
          <div className="flex gap-6">
            <Link href="/about" className="text-sm text-muted-foreground hover:text-primary">
              سياسة الخصوصية
            </Link>
            <Link href="/about" className="text-sm text-muted-foreground hover:text-primary">
              شروط الاستخدام
            </Link>
          </div>
        </div>
        <div className="text-center mt-4">
          <p className="text-sm text-muted-foreground">ملكية الحساب تعود لـ طارق قديرات</p>
        </div>
      </div>
    </footer>
  )
}
