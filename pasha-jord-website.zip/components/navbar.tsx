"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { Search, Menu, X } from "lucide-react"
import { useState } from "react"
import { SearchDialog } from "@/components/search-dialog"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>

          <Link href="/" className="flex items-center gap-2">
            <div className="relative h-8 w-8 overflow-hidden rounded-full">
              <Image src="/logo.png" alt="Pasha_jord Logo" fill className="object-cover" />
            </div>
            <span className="font-bold text-xl hidden sm:inline-block">Pasha_jord</span>
          </Link>
        </div>

        <nav
          className={`${isMenuOpen ? "flex" : "hidden"} md:flex absolute md:relative top-16 md:top-0 left-0 right-0 flex-col md:flex-row items-center gap-6 bg-background md:bg-transparent p-4 md:p-0 border-b md:border-0`}
        >
          <Link href="/" className="font-medium hover:text-primary transition-colors">
            الرئيسية
          </Link>
          <Link href="/apps" className="font-medium hover:text-primary transition-colors">
            تطبيقات
          </Link>
          <Link href="/websites" className="font-medium hover:text-primary transition-colors">
            مواقع
          </Link>
          <Link href="/telegram-bots" className="font-medium hover:text-primary transition-colors">
            بوتات تلجرام
          </Link>
          <Link href="/blog" className="font-medium hover:text-primary transition-colors">
            المدونة
          </Link>
          <Link href="/about" className="font-medium hover:text-primary transition-colors">
            من نحن
          </Link>
          <Button variant="ghost" size="icon" className="md:hidden mt-2" onClick={() => setIsSearchOpen(true)}>
            <Search className="h-5 w-5" />
            <span className="sr-only">بحث</span>
          </Button>
        </nav>

        <div className="flex items-center gap-4">
          <div className="relative hidden md:flex items-center">
            <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(true)}>
              <Search className="h-5 w-5" />
              <span className="sr-only">بحث</span>
            </Button>
          </div>
          <ModeToggle />
        </div>
      </div>
      <SearchDialog open={isSearchOpen} onOpenChange={setIsSearchOpen} />
    </header>
  )
}
