import PomegranateAd from "./pomegranate-ad"

export default function AdBanner() {
  return (
    <div className="py-4 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center text-xs text-muted-foreground mb-2">إعلان</div>
        <PomegranateAd />
      </div>
    </div>
  )
}
