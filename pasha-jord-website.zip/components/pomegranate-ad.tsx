"use client"

import { useEffect, useRef } from "react"

export default function PomegranateAd() {
  const adContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Create the first script element (atOptions)
    const scriptOptions = document.createElement("script")
    scriptOptions.type = "text/javascript"
    scriptOptions.text = `
      atOptions = {
        'key' : '5c97ba026e68825b1b6ef6eead4bd51a',
        'format' : 'iframe',
        'height' : 50,
        'width' : 320,
        'params' : {}
      };
    `

    // Create the second script element (invoke.js)
    const scriptInvoke = document.createElement("script")
    scriptInvoke.type = "text/javascript"
    scriptInvoke.src = "//pomegranatestaff.com/5c97ba026e68825b1b6ef6eead4bd51a/invoke.js"
    scriptInvoke.async = true

    // Append scripts to the container
    if (adContainerRef.current) {
      adContainerRef.current.appendChild(scriptOptions)
      adContainerRef.current.appendChild(scriptInvoke)
    }

    // Cleanup function
    return () => {
      if (adContainerRef.current) {
        if (scriptOptions.parentNode === adContainerRef.current) {
          adContainerRef.current.removeChild(scriptOptions)
        }
        if (scriptInvoke.parentNode === adContainerRef.current) {
          adContainerRef.current.removeChild(scriptInvoke)
        }
      }
    }
  }, [])

  return <div ref={adContainerRef} className="flex justify-center my-4" />
}
