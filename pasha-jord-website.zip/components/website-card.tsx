import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronRight, TrendingUp } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export function WebsiteCard({
  id,
  title,
  description,
  category,
  trending,
  websiteLink,
  icon,
}: {
  id: number
  title: string
  description: string
  category: string
  trending: boolean
  websiteLink: string
  icon?: string
}) {
  // استخدام الأيقونة الحقيقية أو أيقونة افتراضية
  const iconSrc = icon || "/images/websites/default-website-icon.png"

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="relative h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center overflow-hidden">
            <Image src={iconSrc || "/placeholder.svg"} alt={title} width={48} height={48} className="object-contain" />
          </div>
          {trending && (
            <div className="flex items-center text-orange-500">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">رائج</span>
            </div>
          )}
        </div>
        <CardTitle className="mt-4">{title}</CardTitle>
        <CardDescription>{category}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3">{description}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/websites/${id}`} className="w-full">
          <Button variant="outline" className="w-full">
            التفاصيل
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
