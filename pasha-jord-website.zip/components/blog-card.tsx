import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export function BlogCard({
  title,
  category,
  date,
  excerpt,
  slug,
  image,
}: {
  title: string
  category: string
  date: string
  excerpt: string
  slug: string
  image?: string
}) {
  // استخدام صورة المقال الحقيقية أو صورة افتراضية حسب الفئة
  let imageSrc = image

  if (!imageSrc) {
    if (category === "تطبيقات") {
      imageSrc = "/images/blog/app-collection.png"
    } else if (category === "السوشيال ميديا") {
      imageSrc = "/images/blog/social-media-apps.png"
    } else if (category === "إنشاء المحتوى") {
      imageSrc = "/images/blog/web-design-purple.png"
    } else {
      imageSrc = "/images/blog/web-development.png"
    }
  }

  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 bg-muted">
        <Image src={imageSrc || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <CardHeader>
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-primary">{category}</span>
          <span className="text-xs text-muted-foreground">{date}</span>
        </div>
        <CardTitle className="line-clamp-2">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3">{excerpt}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/blog/${slug}`} className="w-full">
          <Button variant="ghost" className="w-full">
            قراءة المزيد
            <ChevronRight className="mr-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
