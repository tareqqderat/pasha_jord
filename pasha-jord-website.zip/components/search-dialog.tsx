"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, Smartphone, Globe, MessageCircle, FileText, X } from "lucide-react"
import { useRouter } from "next/navigation"

type SearchItem = {
  id: string
  title: string
  description: string
  category: string
  type: "app" | "website" | "bot" | "blog"
  url: string
  icon: React.ReactNode
}

const searchData: SearchItem[] = [
  {
    id: "app-1",
    title: "Pixverse",
    description: "تطبيق رائع لتحرير الصور وإضافة تأثيرات مميزة",
    category: "تحرير الصور",
    type: "app",
    url: "/apps#app-1",
    icon: <Smartphone className="h-5 w-5 text-primary" />,
  },
  {
    id: "app-2",
    title: "ChatGPT",
    description: "تطبيق الذكاء الاصطناعي الشهير للمحادثة والمساعدة",
    category: "الذكاء الاصطناعي",
    type: "app",
    url: "/apps#app-2",
    icon: <Smartphone className="h-5 w-5 text-primary" />,
  },
  {
    id: "app-3",
    title: "CapCut",
    description: "تطبيق احترافي لتحرير الفيديوهات",
    category: "تحرير الفيديو",
    type: "app",
    url: "/apps#app-3",
    icon: <Smartphone className="h-5 w-5 text-primary" />,
  },
  {
    id: "website-1",
    title: "Pixverse",
    description: "موقع مميز لتحرير الصور وإضافة تأثيرات احترافية",
    category: "تحرير الصور",
    type: "website",
    url: "/websites#website-1",
    icon: <Globe className="h-5 w-5 text-primary" />,
  },
  {
    id: "website-2",
    title: "إنشاء محادثة وهمية",
    description: "موقع يتيح لك إنشاء محادثات وهمية بين شخصيات مختلفة",
    category: "أدوات إبداعية",
    type: "website",
    url: "/websites#website-2",
    icon: <Globe className="h-5 w-5 text-primary" />,
  },
  {
    id: "website-3",
    title: "إنشاء هوية مزورة",
    description: "موقع لإنشاء هويات افتراضية للاستخدام في الاختبارات والتجارب",
    category: "أدوات",
    type: "website",
    url: "/websites#website-3",
    icon: <Globe className="h-5 w-5 text-primary" />,
  },
  {
    id: "website-4",
    title: "مشاهدة الستوري بشكل سري",
    description: "موقع يتيح لك مشاهدة قصص انستقرام دون ترك أثر",
    category: "أدوات السوشيال ميديا",
    type: "website",
    url: "/websites#website-4",
    icon: <Globe className="h-5 w-5 text-primary" />,
  },
  {
    id: "bot-1",
    title: "بوت تصوير الأشخاص",
    description: "بوت تلجرام يساعدك في تصوير الأشخاص بطريقة مميزة",
    category: "تصوير",
    type: "bot",
    url: "/telegram-bots#bot-1",
    icon: <MessageCircle className="h-5 w-5 text-primary" />,
  },
  {
    id: "bot-2",
    title: "بوت تحميل الفيديوهات",
    description: "بوت تلجرام يساعدك في تحميل الفيديوهات من مختلف المنصات",
    category: "تحميل",
    type: "bot",
    url: "/telegram-bots#bot-2",
    icon: <MessageCircle className="h-5 w-5 text-primary" />,
  },
  {
    id: "blog-1",
    title: "أفضل 10 تطبيقات لتحرير الصور في 2025",
    description: "استعراض لأفضل تطبيقات تحرير الصور المتاحة حالياً",
    category: "تطبيقات",
    type: "blog",
    url: "/blog/best-photo-editing-apps-2025",
    icon: <FileText className="h-5 w-5 text-primary" />,
  },
  {
    id: "blog-2",
    title: "كيفية زيادة متابعينك على انستقرام في 2025",
    description: "نصائح وإستراتيجيات فعالة لزيادة عدد متابعيك على انستقرام",
    category: "السوشيال ميديا",
    type: "blog",
    url: "/blog/increase-instagram-followers-2025",
    icon: <FileText className="h-5 w-5 text-primary" />,
  },
  {
    id: "blog-3",
    title: "دليل شامل لإنشاء محتوى فيديو احترافي",
    description: "خطوات تفصيلية لإنشاء محتوى فيديو احترافي باستخدام أدوات بسيطة",
    category: "إنشاء المحتوى",
    type: "blog",
    url: "/blog/professional-video-content-guide",
    icon: <FileText className="h-5 w-5 text-primary" />,
  },
]

export function SearchDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [searchQuery, setSearchQuery] = useState("")
  const [results, setResults] = useState<SearchItem[]>([])
  const router = useRouter()

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setResults([])
      return
    }

    const filteredResults = searchData.filter(
      (item) =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()),
    )

    setResults(filteredResults)
  }, [searchQuery])

  const handleItemClick = (url: string) => {
    router.push(url)
    onOpenChange(false)
    setSearchQuery("")
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "app":
        return "تطبيق"
      case "website":
        return "موقع"
      case "bot":
        return "بوت تلجرام"
      case "blog":
        return "مقال"
      default:
        return type
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "app":
        return <Smartphone className="h-4 w-4" />
      case "website":
        return <Globe className="h-4 w-4" />
      case "bot":
        return <MessageCircle className="h-4 w-4" />
      case "blog":
        return <FileText className="h-4 w-4" />
      default:
        return null
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-center text-xl">البحث في الموقع</DialogTitle>
        </DialogHeader>
        <div className="relative">
          <Search className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="ابحث عن تطبيق، موقع، بوت تلجرام، أو مقال..."
            className="pr-10 py-6"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
          />
          {searchQuery && (
            <Button variant="ghost" size="icon" className="absolute left-3 top-3" onClick={() => setSearchQuery("")}>
              <X className="h-5 w-5" />
            </Button>
          )}
        </div>

        {results.length > 0 ? (
          <div className="space-y-4 mt-4">
            {results.map((item) => (
              <div
                key={item.id}
                className="p-4 border rounded-lg hover:bg-muted cursor-pointer transition-colors"
                onClick={() => handleItemClick(item.url)}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">{item.icon}</div>
                  <div>
                    <h3 className="font-medium">{item.title}</h3>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        {getTypeIcon(item.type)}
                        <span>{getTypeLabel(item.type)}</span>
                      </div>
                      <span>•</span>
                      <span>{item.category}</span>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
              </div>
            ))}
          </div>
        ) : searchQuery ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>لا توجد نتائج مطابقة لـ "{searchQuery}"</p>
            <p className="text-sm mt-2">حاول استخدام كلمات مفتاحية أخرى أو تحقق من الإملاء</p>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}
