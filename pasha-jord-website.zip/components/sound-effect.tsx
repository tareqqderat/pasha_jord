"use client"

import type React from "react"

import { useEffect, useRef } from "react"

export function useSoundEffect() {
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    // Create audio element
    audioRef.current = new Audio("/sounds/click.mp3")
    audioRef.current.volume = 0.2 // Set volume to 20%

    return () => {
      // Cleanup
      if (audioRef.current) {
        audioRef.current = null
      }
    }
  }, [])

  const playSound = () => {
    if (audioRef.current) {
      // Reset audio to start if it's already playing
      audioRef.current.currentTime = 0
      audioRef.current.play().catch((err) => {
        // Ignore autoplay errors (common in some browsers)
        console.log("Audio play error:", err)
      })
    }
  }

  return playSound
}

export function SoundProvider({ children }: { children: React.ReactNode }) {
  const playSound = useSoundEffect()

  useEffect(() => {
    // Add click event listener to all buttons
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const button = target.closest("button") || target.closest("a")

      if (button) {
        playSound()
      }
    }

    document.addEventListener("click", handleClick)

    return () => {
      document.removeEventListener("click", handleClick)
    }
  }, [playSound])

  return <>{children}</>
}
